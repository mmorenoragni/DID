# Configurar DataSource JNDI en WebLogic 12c (Oracle en Docker)

Guía para crear el recurso `jdbc/OracleDS` en la consola de WebLogic 12c, apuntando a Oracle Database Free en Docker.

## Requisitos previos

- WebLogic 12c en ejecución.
- Oracle Database Free en Docker accesible (por ejemplo `localhost:1521`).
- Credenciales de la base: usuario `system`, contraseña `oracle`, servicio `FREEPDB1`.

---

## Paso 1: Acceder a la consola de administración

1. Abre el navegador y entra a la consola de WebLogic, por ejemplo:
   - `http://localhost:7001/console`
2. Inicia sesión con el usuario y contraseña del dominio (por ejemplo `weblogic` / `welcome1`).

---

## Paso 2: Ir a la creación del Data Source

1. En el **panel izquierdo**, bajo **Estructura de dominio**, haz clic en **Servicios** → **Orígenes de datos**.
2. En la tabla **Orígenes de datos**, haz clic en **Nuevo** → **Origen de datos genérico**.

---

## Paso 3: Configurar nombre y JNDI

1. **Nombre**: `OracleDS` (o el nombre que prefieras; es solo identificador en la consola).
2. **Nombre JNDI**: `jdbc/OracleDS`  
   Debe ser exactamente este valor para que coincida con la aplicación.
3. **Driver de base de datos**: selecciona **Oracle's Driver (Thin) for Service IDs; Versión: Any**.
4. Clic en **Siguiente**.

---

## Paso 4: Opciones de transacción

1. Deja la opción por defecto (por ejemplo **Transacciones de uno y dos fases** o **One-Phase Commit** según tu versión).
2. Clic en **Siguiente**.

---

## Paso 5: Propiedades de conexión

Introduce los datos de tu Oracle en Docker:

| Propiedad   | Valor |
|------------|--------|
| **Nombre del host** | `localhost` |
| **Puerto**          | `1521` |
| **Nombre de la base de datos** | `FREEPDB1` (nombre del PDB) |
| **Nombre de usuario** | `system` |
| **Contraseña**        | `oracle` |
| **Confirmar contraseña** | `oracle` |

En algunas versiones de WebLogic 12c el formulario pide **URL** en lugar de host/puerto/DB. En ese caso usa:

- **URL**: `jdbc:oracle:thin:@localhost:1521/FREEPDB1`
- **Nombre de usuario**: `system`
- **Contraseña**: `oracle`

Clic en **Siguiente**.

---

## Paso 6: Prueba de conexión (opcional)

1. Si la consola ofrece **Probar configuración**, ejecútala.
2. Debe indicar que la conexión fue exitosa. Si falla:
   - Comprueba que el contenedor Oracle esté en marcha: `docker ps`.
   - Que el puerto 1521 esté publicado y que desde la máquina donde corre WebLogic puedas conectar a `localhost:1521`.
3. Clic en **Siguiente**.

---

## Paso 7: Asignar al servidor

1. Selecciona el **servidor** (o cluster) donde está desplegada la aplicación `ws-actas-dnid`.
2. Mueve ese servidor a la columna **Objetivo** (o marca la casilla correspondiente).
3. Clic en **Finalizar**.

---

## Paso 8: Activar los cambios

1. En la parte superior de la consola, haz clic en **Activar cambios** (o **Cambios pendientes** → **Activar**).
2. Espera a que los cambios se apliquen.

---

## Paso 9: Comprobar el DataSource

1. En **Servicios** → **Orígenes de datos**, deberías ver `OracleDS` con estado **Activo** (o **Running**).
2. Prueba la aplicación, por ejemplo:
   - `http://localhost:7001/ws-actas-dnid/db-test`  
   Debe devolver JSON con `"status":"OK"` si el JNDI y la conexión están bien.

---

## Resumen de valores para Oracle en Docker

| Concepto        | Valor |
|-----------------|--------|
| JNDI Name       | `jdbc/OracleDS` |
| Driver          | Oracle's Driver (Thin) for Service IDs |
| URL             | `jdbc:oracle:thin:@localhost:1521/FREEPDB1` |
| Usuario         | `system` |
| Contraseña      | `oracle` |

---

## Si WebLogic y Oracle no están en la misma máquina

- **Host**: usa la IP o hostname del equipo donde corre el contenedor Oracle (no `localhost` si WebLogic está en otro servidor).
- Asegúrate de que el puerto 1521 esté abierto en el firewall y que el listener de Oracle acepte conexiones desde esa IP.

---

---

## Vincular el DataSource a la aplicación ya desplegada

Si creaste el DataSource **después** de desplegar la app, o desplegaste sin el `weblogic.xml` actualizado, la aplicación no “ve” el JNDI y puede devolver:

`"Error al buscar el DataSource JNDI: java:comp/env/jdbc/OracleDS"`

Sigue estos pasos para vincular el DataSource a la aplicación ya desplegada.

### 1. Comprobar el nombre JNDI del DataSource

1. **Servicios** → **Orígenes de datos**.
2. Haz clic en el nombre de tu DataSource (por ejemplo `OracleDS`).
3. Abre la pestaña **Configuración** (o **Configuration**).
4. En **Nombre JNDI** debe figurar exactamente: **`jdbc/OracleDS`**.
   - Si pone otro valor (por ejemplo `OracleDS` o `jdbc.OracleDS` en otro formato), anótalo; lo usarás en el paso 3 o tendrás que editarlo para que sea `jdbc/OracleDS`.
5. En **Objetivos** (Targets) debe estar el **mismo servidor** donde está desplegada `ws-actas-dnid`. Si no, asígnalo y **Activar cambios**.

### 2. Ir a la configuración del despliegue

1. En el menú izquierdo: **Despliegues** (o **Deployments**).
2. En la tabla, localiza **ws-actas-dnid** y haz **clic en el nombre** (enlace), no solo en la casilla.
3. Se abrirá la ficha del despliegue con pestañas como **Configuración**, **Supervisión**, etc.

### 3. Asignar la referencia de recurso al JNDI global

1. Entra en la pestaña **Configuración** (Configuration).
2. Busca una subpestaña o sección llamada **Referencias** (References) o **Referencias de recursos** (Resource references).
3. Deberías ver la referencia **`jdbc/OracleDS`** (la que declara la aplicación en `web.xml`).
4. En esa fila, en el campo **Nombre JNDI** (o **JNDI Name** / **Objetivo**), indica el **nombre JNDI global** del DataSource que creaste:
   - Si en el paso 1 el DataSource tiene JNDI **`jdbc/OracleDS`**, escribe exactamente: **`jdbc/OracleDS`**.
   - Si en tu consola el DataSource tiene otro JNDI (por ejemplo `OracleDS`), escribe ese mismo valor aquí.
5. Guarda (por ejemplo **Guardar** o **Save**).
6. Arriba en la consola: **Activar cambios** (o **Cambios pendientes** → **Activar**).

Si en tu versión de WebLogic **no aparece** la sección “Referencias” o no se puede editar el JNDI, usa la opción **4. Alternativa: redesplegar el WAR**.

### 4. Alternativa: redesplegar el WAR

El vínculo también se define en `WEB-INF/weblogic.xml` del WAR. Si la app se desplegó con un WAR antiguo (sin ese `resource-description`), conviene redesplegar el WAR actual:

1. **Despliegues** → marca la casilla de **ws-actas-dnid**.
2. Clic en **Actualizar** (o **Update** / **Redeploy**).
3. Elige **Subir un nuevo archivo** (o **Redeploy**) y selecciona el WAR actual: `ws-actas-dnid.war` (el que incluye `weblogic.xml` con el `<resource-description>` de `jdbc/OracleDS`).
4. Siguiente hasta finalizar y **Activar cambios**.

Así WebLogic volverá a leer el `weblogic.xml` y mapeará `java:comp/env/jdbc/OracleDS` al JNDI global del DataSource (por ejemplo `jdbc/OracleDS`).

### 5. Reiniciar la aplicación (recomendado)

1. **Despliegues** → marca **ws-actas-dnid**.
2. **Detener** (Stop).
3. Esperar a que quede en estado “Preparado” o “Stopped”.
4. **Iniciar** (Start).

Luego prueba de nuevo:

- `http://localhost:7001/ws-actas-dnid/db-test`  
  Debe devolver algo como: `{"status":"OK", ...}`.

### Resumen del vínculo

- La aplicación hace lookup de **`java:comp/env/jdbc/OracleDS`** (referencia de recurso).
- WebLogic debe resolver esa referencia al **nombre JNDI global** del DataSource (por ejemplo **`jdbc/OracleDS`**).
- Ese vínculo se configura en la consola (Referencias del despliegue) o en el `weblogic.xml` del WAR al desplegar.
- El DataSource debe estar **asignado al mismo servidor** donde corre la aplicación.

---

## Solución de problemas

- **No se encuentra el DataSource / NamingException**: el JNDI en WebLogic debe ser exactamente `jdbc/OracleDS` y el `<jndi-name>` en `WEB-INF/weblogic.xml` debe coincidir. Si la app ya estaba desplegada, vincula la referencia (pasos anteriores) o redespliega el WAR.
- **Error de conexión al probar**: verifica que Oracle esté arriba (`docker ps`), que 1521 esté mapeado y que usuario/contraseña/PDB sean correctos.
- **Driver no encontrado**: en WebLogic 12c el driver Oracle Thin suele estar incluido; si no, debes instalar el driver Oracle en el dominio (por ejemplo en `$DOMAIN_HOME/lib`) y reiniciar.
