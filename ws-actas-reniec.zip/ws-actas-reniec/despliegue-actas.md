# Despliegue del WAR en WebLogic y consumo de la API

Este documento describe cómo desplegar el archivo WAR de **ws-actas-dnid** en Oracle WebLogic y cómo consumir los endpoints expuestos. Se asume que el usuario ya dispone del archivo `.war` y no necesita compilarlo.

---

## 1. Requisitos previos

- Servidor **Oracle WebLogic** (por ejemplo 12c) en ejecución.
- **DataSource Oracle** configurado en WebLogic con el JNDI que utiliza la aplicación (ver siguiente sección).
- Archivo **ws-actas-dnid.war** listo para desplegar.

---

## 2. Configuración del DataSource JNDI

La aplicación utiliza un único DataSource con nombre JNDI global **`jdbc/desarc`**. Debe existir en WebLogic antes o durante el despliegue.

### Pasos en la consola de WebLogic

1. Acceder a la **consola de administración** (ej.: `http://<servidor>:7001/console`).
2. Ir a **Servicios** → **Orígenes de datos** → **Nuevo** → **Origen de datos genérico**.
3. Configurar:
   - **Nombre:** por ejemplo `DesarcDS`.
   - **Nombre JNDI:** `jdbc/desarc` (debe coincidir exactamente).
   - **Driver:** Oracle's Driver (Thin) for Service IDs (u otro driver Oracle según su versión).
4. En **Propiedades de conexión**, indicar según su entorno:
   - **URL:** p. ej. `jdbc:oracle:thin:@<host>:<puerto>/<servicio>`
   - **Usuario** y **Contraseña** del esquema que ejecuta los procedimientos almacenados.
5. **Objetivo:** asignar el DataSource al servidor o cluster donde se desplegará la aplicación.
6. **Activar** los cambios.

Si en su entorno el JNDI global es distinto de `jdbc/desarc`, debe editar el elemento `<jndi-name>` en `WEB-INF/weblogic.xml` del WAR para que coincida antes de desplegar.

---

## 3. Despliegue del WAR

### 3.1 Instalación del archivo

1. En la consola de WebLogic: **Despliegues** → **Instalar** (o **Lock & Edit** y luego **Instalar** si la consola lo requiere).
2. Seleccionar **Cargar el archivo** (o elegir el archivo desde una ruta accesible por el servidor).
3. Subir o indicar la ruta de **ws-actas-dnid.war**.
4. Elegir **Instalar como aplicación**.
5. Dejar el **nombre del contexto** por defecto o el que desee; la aplicación está preparada para exponerse en **context root** `/ws-actas-dnid` (definido en el WAR). Si no lo cambia en el asistente, la URL base será:
   ```text
   http://<host>:<puerto>/ws-actas-dnid
   ```
6. Asignar el despliegue al mismo **servidor/cluster** donde está el DataSource `jdbc/desarc`.
7. Finalizar el asistente y **Activar** los cambios si la consola está en modo edición.

### 3.2 Verificación del despliegue

- Comprobar que el estado del despliegue sea **Activo**.
- Probar el health check (ver sección 5.1):
  ```bash
  curl -s "http://<host>:<puerto>/ws-actas-dnid/health"
  ```
  Si el DataSource está correcto, la respuesta incluirá `"status":"UP"`.

---

## 4. URL base y formato de las peticiones

- **URL base de ejemplo:** `http://localhost:7001/ws-actas-dnid`
- Las respuestas de la API son **JSON** con codificación **UTF-8**.

---

## 5. Operaciones de la API y ejemplos con curl

### 5.1 Health check (estado del DataSource)

Comprueba el estado de la conexión JNDI `jdbc/desarc`.

| Método | Ruta        | Descripción                    |
|--------|-------------|--------------------------------|
| GET    | `/health`   | Estado de la conexión y, opcionalmente, directorio de archivos |

**Ejemplo curl:**

```bash
curl -s -X GET "http://localhost:7001/ws-actas-dnid/health"
```

**Respuesta exitosa (200 OK):**

```json
{
  "connections": {
    "jdbc/desarc": {
      "name": "jdbc/desarc",
      "status": "UP"
    }
  },
  "status": "UP",
  "fileRoot": "/ruta/resuelta/oracle/dnid/config",
  "fileRootFiles": []
}
```

**Respuesta cuando el DataSource falla (503 Service Unavailable):**

```json
{
  "connections": {
    "jdbc/desarc": {
      "name": "jdbc/desarc",
      "status": "DOWN",
      "message": "No se pudo obtener conexión JNDI: jdbc/desarc. Verifique el DataSource en WebLogic."
    }
  },
  "status": "DOWN",
  "fileRoot": "...",
  "fileRootFiles": []
}
```

---

### 5.2 Obtener datos (acta de nacimiento o acta de matrimonio)

Un único endpoint **POST** permite consultar por **profile**. Los parámetros se envían en el cuerpo en **JSON** o como **form-urlencoded**.

| Método | Ruta               | Descripción                                      |
|--------|--------------------|--------------------------------------------------|
| POST   | `/ObtenerDatosDNId`| Consulta según `profile` (ACTA_NACIMIENTO, ACTA_MATRIMONIO) |

**Parámetros comunes:**

- **profile** (obligatorio): `ACTA_NACIMIENTO` o `ACTA_MATRIMONIO`
- **dni**: según el profile, número de acta (ACTA_NACIMIENTO) o número de DNI (ACTA_MATRIMONIO)

---

#### 5.2.1 Profile ACTA_NACIMIENTO

Consulta acta de nacimiento por número de acta. Parámetro: **dni** (valor = número de acta).

**Ejemplo curl (JSON):**

```bash
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -H "Content-Type: application/json" \
  -d '{"profile":"ACTA_NACIMIENTO","dni":"1001"}'
```

**Ejemplo curl (form-urlencoded):**

```bash
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -d "profile=ACTA_NACIMIENTO" \
  -d "dni=1001"
```

**Respuesta exitosa (200 OK):** JSON con las columnas devueltas por el procedimiento almacenado (estructura depende del SP; puede incluir fechas, BLOB en Base64, etc.).

---

#### 5.2.2 Profile ACTA_MATRIMONIO

Consulta acta de matrimonio por número de DNI. Parámetro: **dni** (valor = DNI de la persona).

**Ejemplo curl (JSON):**

```bash
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -H "Content-Type: application/json" \
  -d '{"profile":"ACTA_MATRIMONIO","dni":"12345678"}'
```

**Ejemplo curl (form-urlencoded):**

```bash
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -d "profile=ACTA_MATRIMONIO" \
  -d "dni=12345678"
```

**Respuesta exitosa (200 OK):** JSON con las columnas devueltas por el procedimiento almacenado de acta de matrimonio.

---

#### Petición GET al mismo path (no permitida)

Si se envía **GET** a `/ObtenerDatosDNId`, la aplicación responde **405 Method Not Allowed** con un mensaje que indica usar POST.

**Ejemplo:**

```bash
curl -s -X GET "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId"
```

**Respuesta (405):**

```json
{
  "error": "Método no permitido. Use POST con parámetro profile (ej. DNI) y parámetros según el profile."
}
```

---

## 6. Excepciones y códigos de error

Todas las respuestas de error de la API devuelven un JSON con un único campo **`error`** que contiene el mensaje descriptivo. El código HTTP indica el tipo de fallo.

### 6.1 Resumen de códigos HTTP

| Código | Significado                    | Cuándo se produce |
|--------|--------------------------------|--------------------|
| 200    | OK                             | Health check correcto o consulta con datos encontrados |
| 400    | Bad Request                    | Parámetro obligatorio faltante, profile no soportado o parámetro inválido |
| 404    | Not Found                      | No existen datos para la consulta (acta/DNI no encontrado) |
| 405    | Method Not Allowed             | Se usó GET en `/ObtenerDatosDNId` (solo se admite POST) |
| 503    | Service Unavailable            | Health check: el DataSource JNDI no está disponible o falla la conexión |
| 500    | Internal Server Error          | Error de base de datos (SQL) u otro error no controlado en el servidor |

---

### 6.2 Detalle por operación y excepción

#### Health check (`GET /health`)

- **200 OK:** La conexión JNDI `jdbc/desarc` responde correctamente. `"status"` es `"UP"`.
- **503 Service Unavailable:** No se pudo obtener conexión del DataSource. En `connections["jdbc/desarc"]` aparecerá `"status":"DOWN"` y opcionalmente `"message"` con el detalle (por ejemplo mensaje de `SQLException` o que el JNDI no está configurado).

---

#### Obtener datos (`POST /ObtenerDatosDNId`)

**400 Bad Request**

| Situación | Mensaje de error en `error` |
|-----------|------------------------------|
| Falta el parámetro `profile` | `Parámetro 'profile' requerido` |
| Valor de `profile` no soportado | `Profile no soportado: <valor>` |
| ACTA_NACIMIENTO: falta el número de acta | `Parámetro 'acta_nacimiento' requerido` (la aplicación usa el parámetro `dni` en la petición para este valor) |
| ACTA_NACIMIENTO: el valor no es numérico | `El parámetro 'acta_nacimiento' debe ser un número` |
| ACTA_MATRIMONIO: falta el DNI | `Parámetro 'dni' requerido para profile acta_matrimonio` |

**404 Not Found**

| Situación | Mensaje de error en `error` |
|-----------|------------------------------|
| Acta de nacimiento no encontrada | `No se encontraron datos para el acta de nacimiento: <número>` |
| Acta de matrimonio no encontrada para el DNI | `No se encontraron datos de acta de matrimonio para el DNI: <dni>` |

**500 Internal Server Error**

- Error al ejecutar el procedimiento almacenado o al acceder a la base de datos. El campo `error` incluye un texto descriptivo y, si está disponible, la causa (por ejemplo mensaje de Oracle). Ejemplo:
  - `Error al consultar datos: <mensaje SQL> | Causa: <causa>`

**405 Method Not Allowed**

- Se envió GET en lugar de POST. Mensaje:  
  `Método no permitido. Use POST con parámetro profile (ej. DNI) y parámetros según el profile.`

---

### 6.3 Formato estándar de error

Todas las respuestas de error del endpoint `/ObtenerDatosDNId` (y el GET no permitido) tienen la forma:

```json
{
  "error": "Texto descriptivo del error"
}
```

El **Content-Type** es `application/json; charset=UTF-8`. El cliente debe interpretar el código HTTP para distinguir 400, 404, 405 y 500, y usar el campo `error` para logs o mensajes al usuario.

---

## 7. Resumen rápido

- **Despliegue:** Subir el WAR en WebLogic y asegurar que exista el DataSource con JNDI **`jdbc/desarc`**.
- **Health:** `GET /ws-actas-dnid/health` → 200 si todo está bien, 503 si falla el DataSource.
- **Datos:** `POST /ws-actas-dnid/ObtenerDatosDNId` con cuerpo JSON (o form) con `profile` y `dni` según el tipo de consulta.
- **Errores:** Siempre JSON con campo `error`; códigos 400 (validación), 404 (no encontrado), 405 (método no permitido), 500 (error servidor/BD), 503 (health en fallo).
