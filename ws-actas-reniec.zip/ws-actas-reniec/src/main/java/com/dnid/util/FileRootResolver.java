package com.dnid.util;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Resuelve el directorio root de archivos de la aplicación.
 * Si la ruta es relativa, la resuelve con domain.home o weblogic.Domain (WebLogic).
 */
public final class FileRootResolver {

    private FileRootResolver() {
    }

    /**
     * Resuelve el directorio root de archivos: si la ruta es relativa, la resuelve con domain.home o weblogic.Domain.
     *
     * @param pathParam valor del context-param dnid.file.root (puede ser null o vacío)
     * @return ruta absoluta del directorio, o null si pathParam no está configurado
     */
    public static String resolve(String pathParam) {
        if (pathParam == null || pathParam.trim().isEmpty()) {
            return null;
        }
        Path path = Paths.get(pathParam.trim());
        if (!path.isAbsolute()) {
            String domainHome = System.getProperty("domain.home");
            if (domainHome != null && !domainHome.isEmpty()) {
                path = Paths.get(domainHome, pathParam.trim());
            } else {
                String wlDomain = System.getProperty("weblogic.Domain");
                if (wlDomain != null && !wlDomain.isEmpty()) {
                    path = Paths.get(wlDomain, pathParam.trim());
                }
            }
        }
        return path.toAbsolutePath().normalize().toString();
    }
}
