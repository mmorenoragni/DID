package com.dnid.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Clase utilitaria para manejar conexiones a base de datos.
 * Obtiene conexiones únicamente desde los DataSource JNDI jdbc/desarc y jdbc/desadni (WebLogic).
 */
public class DatabaseConnection {

    private static final String JNDI_DESARC = "java:comp/env/jdbc/desarc";
    private static final String JNDI_DESADNI = "java:comp/env/jdbc/desadni";

    private static Connection fromJndi(String jndiName) throws SQLException {
        try {
            InitialContext ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup(jndiName);
            return ds != null ? ds.getConnection() : null;
        } catch (NamingException e) {
            return null;
        }
    }

    /**
     * Obtiene una conexión desde el DataSource JNDI jdbc/desarc.
     *
     * @return Connection del pool jdbc/desarc
     * @throws SQLException si el JNDI no está disponible o falla la conexión
     */
    public static Connection getConnectionDesarc() throws SQLException {
        Connection c = fromJndi(JNDI_DESARC);
        if (c != null) return c;
        throw new SQLException("No se pudo obtener conexión JNDI: jdbc/desarc. Verifique el DataSource en WebLogic.");
    }

    /**
     * Obtiene una conexión desde el DataSource JNDI jdbc/desadni.
     *
     * @return Connection del pool jdbc/desadni
     * @throws SQLException si el JNDI no está disponible o falla la conexión
     */
    public static Connection getConnectionDesadni() throws SQLException {
        Connection c = fromJndi(JNDI_DESADNI);
        if (c != null) return c;
        throw new SQLException("No se pudo obtener conexión JNDI: jdbc/desadni. Verifique el DataSource en WebLogic.");
    }

    /**
     * Cierra una conexión de forma segura.
     *
     * @param connection conexión a cerrar
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}
