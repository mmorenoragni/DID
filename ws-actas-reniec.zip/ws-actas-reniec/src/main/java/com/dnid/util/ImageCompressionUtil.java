package com.dnid.util;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Iterator;

/**
 * Utilidad para codificar imágenes a Base64 con compresión opcional cuando
 * el tamaño en bytes supera un umbral (redimensionado y/o reducción de calidad JPEG).
 */
public final class ImageCompressionUtil {

    /** DPI usado al renderizar la primera página de un PDF a imagen. */
    public static final float PDF_RENDER_DPI = 150f;

    /** Resultado de compresión: Base64, tamaños en bytes, opcionalmente motivo de fallo y si fue convertido desde PDF. */
    public static final class CompressionResult {
        public final String base64;
        public final long originalSizeBytes;
        public final long compressedSizeBytes;
        /** Si no es null, la compresión falló y se devolvió la imagen original; este es el motivo. */
        public final String motivoFalloCompresion;
        /** true si el BLOB era PDF y se convirtió a JPEG; false en caso contrario. */
        public final boolean wasConverted;
        /** Base64 de la segunda página del PDF (reverso); null si no es PDF o el PDF tiene solo una página. */
        public final String reversoBase64;

        public CompressionResult(String base64, long originalSizeBytes, long compressedSizeBytes) {
            this(base64, originalSizeBytes, compressedSizeBytes, null, false, null);
        }

        public CompressionResult(String base64, long originalSizeBytes, long compressedSizeBytes, String motivoFalloCompresion) {
            this(base64, originalSizeBytes, compressedSizeBytes, motivoFalloCompresion, false, null);
        }

        public CompressionResult(String base64, long originalSizeBytes, long compressedSizeBytes, String motivoFalloCompresion, boolean wasConverted) {
            this(base64, originalSizeBytes, compressedSizeBytes, motivoFalloCompresion, wasConverted, null);
        }

        public CompressionResult(String base64, long originalSizeBytes, long compressedSizeBytes, String motivoFalloCompresion, boolean wasConverted, String reversoBase64) {
            this.base64 = base64;
            this.originalSizeBytes = originalSizeBytes;
            this.compressedSizeBytes = compressedSizeBytes;
            this.motivoFalloCompresion = motivoFalloCompresion;
            this.wasConverted = wasConverted;
            this.reversoBase64 = reversoBase64;
        }
    }

    /** Umbral por defecto: 500 KB. Por debajo no se comprime. */
    public static final long DEFAULT_MAX_SIZE_BYTES = 5000L;

    /** Ancho máximo en píxeles por defecto al redimensionar. */
    public static final int DEFAULT_MAX_WIDTH = 64;

    /** Calidad JPEG por defecto (0.0f–1.0f). */
    public static final float DEFAULT_JPEG_QUALITY = 0.75f;

    private ImageCompressionUtil() {
    }

    /**
     * Devuelve la imagen como Base64. Si el tamaño supera {@code maxSizeBytes},
     * la comprime (escala hasta {@code maxWidth} y escribe como JPEG con
     * {@code jpegQuality}) y devuelve Base64 del resultado. Si la lectura o
     * escritura falla, devuelve Base64 del array original.
     *
     * @param imageBytes   bytes de la imagen (JPEG, PNG, etc.)
     * @param maxSizeBytes umbral en bytes; por debajo no se comprime
     * @param maxWidth     ancho máximo en píxeles al redimensionar
     * @param jpegQuality  calidad JPEG 0.0f–1.0f al comprimir
     * @return Base64 de la imagen (original o comprimida)
     */
    public static String toBase64WithCompressionIfNeeded(byte[] imageBytes, long maxSizeBytes,
                                                        int maxWidth, float jpegQuality) {
        if (imageBytes == null || imageBytes.length == 0) {
            return Base64.getEncoder().encodeToString(new byte[0]);
        }
        if (imageBytes.length <= maxSizeBytes) {
            return Base64.getEncoder().encodeToString(imageBytes);
        }
        try {
            byte[] compressed = compressImage(imageBytes, maxWidth, jpegQuality);
            return Base64.getEncoder().encodeToString(compressed);
        } catch (IOException e) {
            return Base64.getEncoder().encodeToString(imageBytes);
        }
    }

    /**
     * Usa constantes por defecto: 500 KB, max width 1024, calidad 0.75.
     */
    public static String toBase64WithCompressionIfNeeded(byte[] imageBytes) {
        return toBase64WithCompressionIfNeeded(imageBytes,
                DEFAULT_MAX_SIZE_BYTES, DEFAULT_MAX_WIDTH, DEFAULT_JPEG_QUALITY);
    }

    /**
     * Igual que {@link #toBase64WithCompressionIfNeeded(byte[], long, int, float)} pero devuelve
     * además el tamaño original y el tamaño final (comprimido o igual si no se comprimió).
     */
    public static CompressionResult toBase64WithCompressionAndSizes(byte[] imageBytes, long maxSizeBytes,
                                                                   int maxWidth, float jpegQuality) {
        if (imageBytes == null || imageBytes.length == 0) {
            return new CompressionResult(Base64.getEncoder().encodeToString(new byte[0]), 0, 0);
        }
        long originalSize = imageBytes.length;
        if (imageBytes.length <= maxSizeBytes) {
            String base64 = Base64.getEncoder().encodeToString(imageBytes);
            return new CompressionResult(base64, originalSize, originalSize);
        }
        try {
            byte[] compressed = compressImage(imageBytes, maxWidth, jpegQuality);
            String base64 = Base64.getEncoder().encodeToString(compressed);
            return new CompressionResult(base64, originalSize, compressed.length);
        } catch (IOException e) {
            String detalle = e.getMessage();
            if (e.getCause() != null && e.getCause().getMessage() != null) {
                detalle = detalle + " | Causa: " + e.getCause().getMessage();
            }
            detalle = detalle + ". " + buildDiagnosticoBytes(imageBytes);
            String base64 = Base64.getEncoder().encodeToString(imageBytes);
            return new CompressionResult(base64, originalSize, originalSize, detalle);
        }
    }

    /**
     * Usa constantes por defecto para compresión y devuelve Base64 con tamaños.
     */
    public static CompressionResult toBase64WithCompressionAndSizes(byte[] imageBytes) {
        return toBase64WithCompressionAndSizes(imageBytes,
                DEFAULT_MAX_SIZE_BYTES, DEFAULT_MAX_WIDTH, DEFAULT_JPEG_QUALITY);
    }

    /**
     * Convierte BLOB a Base64: si es PDF se renderizan las dos primeras páginas a JPEG (anverso y reverso);
     * si no es PDF se usa el flujo habitual. Incluye el flag {@code wasConverted} y {@code reversoBase64}
     * (segunda página, o null si el PDF tiene solo una página).
     */
    public static CompressionResult toBase64WithPdfConversionAndSizes(byte[] imageBytes) {
        if (imageBytes == null || imageBytes.length == 0) {
            return new CompressionResult(Base64.getEncoder().encodeToString(new byte[0]), 0, 0, null, false, null);
        }
        long originalSize = imageBytes.length;
        if (!isPdf(imageBytes)) {
            CompressionResult r = toBase64WithCompressionAndSizes(imageBytes);
            return new CompressionResult(r.base64, r.originalSizeBytes, r.compressedSizeBytes, r.motivoFalloCompresion, false, null);
        }
        try {
            PdfTwoPages twoPages = pdfFirstTwoPagesToJpeg(imageBytes);
            CompressionResult rAnverso = toBase64WithCompressionAndSizes(twoPages.anverso);
            String reversoBase64 = null;
            if (twoPages.reverso != null) {
                CompressionResult rReverso = toBase64WithCompressionAndSizes(twoPages.reverso);
                reversoBase64 = rReverso.base64;
            }
            return new CompressionResult(rAnverso.base64, originalSize, rAnverso.compressedSizeBytes, rAnverso.motivoFalloCompresion, true, reversoBase64);
        } catch (IOException e) {
            String base64 = Base64.getEncoder().encodeToString(imageBytes);
            return new CompressionResult(base64, originalSize, originalSize, null, false, null);
        }
    }

    /** Resultado interno: anverso (página 0) y opcionalmente reverso (página 1). */
    private static final class PdfTwoPages {
        final byte[] anverso;
        final byte[] reverso;

        PdfTwoPages(byte[] anverso, byte[] reverso) {
            this.anverso = anverso;
            this.reverso = reverso;
        }
    }

    /**
     * Renderiza las dos primeras páginas del PDF a JPEG. Lanza IOException si no es un PDF válido o falla el renderizado.
     * El reverso es null si el PDF tiene solo una página.
     */
    private static PdfTwoPages pdfFirstTwoPagesToJpeg(byte[] pdfBytes) throws IOException {
        try (PDDocument doc = PDDocument.load(pdfBytes)) {
            if (doc.getNumberOfPages() == 0) {
                throw new IOException("PDF sin páginas");
            }
            PDFRenderer renderer = new PDFRenderer(doc);
            BufferedImage img0 = renderer.renderImageWithDPI(0, PDF_RENDER_DPI);
            byte[] anverso = writeJpeg(img0, DEFAULT_JPEG_QUALITY);
            byte[] reverso = null;
            if (doc.getNumberOfPages() >= 2) {
                BufferedImage img1 = renderer.renderImageWithDPI(1, PDF_RENDER_DPI);
                reverso = writeJpeg(img1, DEFAULT_JPEG_QUALITY);
            }
            return new PdfTwoPages(anverso, reverso);
        }
    }

    /**
     * Construye texto de diagnóstico para incluir en la respuesta de la API cuando falla la compresión:
     * longitud en bytes y primeros bytes en hex (para identificar formato o corrupción).
     */
    private static String buildDiagnosticoBytes(byte[] imageBytes) {
        if (imageBytes == null || imageBytes.length == 0) {
            return "Diagnóstico: longitud=0 bytes, sin datos.";
        }
        int len = imageBytes.length;
        int muestras = Math.min(16, len);
        StringBuilder hex = new StringBuilder();
        for (int i = 0; i < muestras; i++) {
            if (i > 0) hex.append(' ');
            hex.append(String.format("%02X", imageBytes[i] & 0xFF));
        }
        String formatoHint = detectarFormatoPorMagicNumbers(imageBytes);
        if (formatoHint != null) {
            return String.format("Diagnóstico: longitud=%d bytes, primeros bytes (hex)=%s, formato detectado=%s.", len, hex, formatoHint);
        }
        return String.format("Diagnóstico: longitud=%d bytes, primeros bytes (hex)=%s.", len, hex);
    }

    /**
     * Indica si los bytes corresponden a un PDF según los magic bytes al inicio (%PDF).
     */
    public static boolean isPdf(byte[] bytes) {
        if (bytes == null || bytes.length < 4) return false;
        return bytes[0] == 0x25 && bytes[1] == 0x50 && bytes[2] == 0x44 && bytes[3] == 0x46;
    }

    /** Detecta formato por magic numbers (solo los más comunes). */
    private static String detectarFormatoPorMagicNumbers(byte[] b) {
        if (b == null || b.length < 4) return null;
        if (b.length >= 2 && b[0] == (byte) 0xFF && b[1] == (byte) 0xD8) return "JPEG";
        if (b.length >= 8 && b[0] == (byte) 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) return "PNG";
        if (b.length >= 6 && b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46) return "GIF";
        if (b.length >= 2 && b[0] == 0x42 && b[1] == 0x4D) return "BMP";
        if (isPdf(b)) return "PDF";
        return null;
    }

    private static byte[] compressImage(byte[] imageBytes, int maxWidth, float jpegQuality) throws IOException {
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
        if (img == null) {
            throw new IOException("No se pudo leer la imagen");
        }
        int w = img.getWidth();
        int h = img.getHeight();
        if (w <= maxWidth) {
            return writeJpeg(img, jpegQuality);
        }
        int newW = maxWidth;
        int newH = (int) Math.round((double) h * maxWidth / w);
        BufferedImage scaled = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = scaled.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            if (img.getColorModel().hasAlpha()) {
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, newW, newH);
            }
            AffineTransform at = AffineTransform.getScaleInstance((double) newW / w, (double) newH / h);
            g.drawRenderedImage(img, at);
        } finally {
            g.dispose();
        }
        return writeJpeg(scaled, jpegQuality);
    }

    private static byte[] writeJpeg(BufferedImage img, float quality) throws IOException {
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpeg");
        if (!writers.hasNext()) {
            throw new IOException("No hay ImageWriter JPEG disponible");
        }
        ImageWriter writer = writers.next();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ImageOutputStream ios = ImageIO.createImageOutputStream(out)) {
            writer.setOutput(ios);
            ImageWriteParam param = writer.getDefaultWriteParam();
            if (param.canWriteCompressed()) {
                param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                param.setCompressionQuality(quality);
            }
            writer.write(null, new IIOImage(img, null, null), param);
        } finally {
            writer.dispose();
        }
        return out.toByteArray();
    }
}
