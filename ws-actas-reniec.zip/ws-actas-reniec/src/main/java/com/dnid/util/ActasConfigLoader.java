package com.dnid.util;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Carga parámetros de configuración desde el archivo configuracion_actas.csv
 * en el directorio configurado por dnid.file.root.
 */
public final class ActasConfigLoader {

    private static final String CONFIG_FILENAME = "configuracion_actas.csv";
    private static final int DEFAULT_EDAD_THRESHOLD = 18;
    private static final Logger LOG = Logger.getLogger(ActasConfigLoader.class.getName());

    /** Lista para ActaMatrimonio (línea índice 1 = segundo renglón del CSV). Vacía = no filtrar. */
    private static List<String> configFieldsListActaMatrimonio = Collections.emptyList();
    /** Lista para ActaNacimiento y ActaNacimientoConFiliacion (línea índice 2 = tercer renglón del CSV). Vacía = no filtrar. */
    private static List<String> configFieldsListActaNacimiento = Collections.emptyList();

    private ActasConfigLoader() {
    }

    /**
     * Lee la lista de nombres de columnas desde configuracion_actas.csv para una línea dada (0-based).
     * La línea se interpreta como valores separados por coma. Si el archivo no existe o no tiene esa línea, devuelve lista vacía.
     *
     * @param ctx        ServletContext para leer el context-param dnid.file.root
     * @param lineIndex  índice de la línea (0 = primera línea; 1 = segundo renglón; 2 = tercer renglón)
     * @return lista no modificable de nombres de columnas; vacía si no hay configuración
     */
    public static List<String> loadConfigFieldsListAt(ServletContext ctx, int lineIndex) {
        String fileRootParam = ctx != null ? ctx.getInitParameter("dnid.file.root") : null;
        String fileRoot = FileRootResolver.resolve(fileRootParam);
        if (fileRoot == null || fileRoot.isEmpty()) {
            return Collections.emptyList();
        }
        Path configPath = Paths.get(fileRoot, CONFIG_FILENAME);
        if (!Files.isRegularFile(configPath)) {
            LOG.log(Level.FINE, "Archivo de configuración no encontrado: {0}", configPath);
            return Collections.emptyList();
        }
        try {
            List<String> lines = Files.readAllLines(configPath, StandardCharsets.UTF_8);
            if (lines == null || lineIndex < 0 || lineIndex >= lines.size()) {
                return Collections.emptyList();
            }
            String line = lines.get(lineIndex);
            if (line == null || line.trim().isEmpty()) {
                return Collections.emptyList();
            }
            List<String> result = new ArrayList<>();
            for (String token : line.split(",")) {
                String t = token != null ? token.trim() : "";
                if (!t.isEmpty()) {
                    result.add(t);
                }
            }
            return Collections.unmodifiableList(result);
        } catch (IOException e) {
            LOG.log(Level.WARNING, e, () -> "Error leyendo " + configPath + " línea " + lineIndex);
            return Collections.emptyList();
        }
    }

    /**
     * Establece la lista de columnas para filtrar la respuesta de ActaMatrimonioProfileStrategy (línea 2 del CSV).
     */
    public static void setConfigFieldsListActaMatrimonio(List<String> list) {
        configFieldsListActaMatrimonio = list != null ? Collections.unmodifiableList(new ArrayList<>(list)) : Collections.emptyList();
    }

    /**
     * Establece la lista de columnas para filtrar la respuesta de ActaNacimiento y ActaNacimientoConFiliacion (línea 3 del CSV).
     */
    public static void setConfigFieldsListActaNacimiento(List<String> list) {
        configFieldsListActaNacimiento = list != null ? Collections.unmodifiableList(new ArrayList<>(list)) : Collections.emptyList();
    }

    /**
     * Lista de columnas permitidas para ActaMatrimonioProfileStrategy (segundo renglón del CSV). Nunca null.
     */
    public static List<String> getConfigFieldsListActaMatrimonio() {
        return configFieldsListActaMatrimonio;
    }

    /**
     * Lista de columnas permitidas para ActaNacimientoProfileStrategy y ActaNacimientoConFiliacionProfileStrategy (tercer renglón del CSV). Nunca null.
     */
    public static List<String> getConfigFieldsListActaNacimiento() {
        return configFieldsListActaNacimiento;
    }

    /**
     * Lee el valor de EDAD_THRESHOLD desde configuracion_actas.csv (primera línea = entero).
     * Si el archivo es encontrado, se sigue el flujo normal y se usa el valor leído.
     * Si el archivo no se encuentra (o no es legible / contenido inválido), se usa el valor por defecto 18.
     *
     * @param ctx ServletContext para leer el context-param dnid.file.root
     * @return edad umbral (valor del CSV si el archivo existe y es válido; 18 por defecto en caso contrario)
     */
    public static int loadEdadThreshold(ServletContext ctx) {
        String fileRootParam = ctx != null ? ctx.getInitParameter("dnid.file.root") : null;
        String fileRoot = FileRootResolver.resolve(fileRootParam);
        if (fileRoot == null || fileRoot.isEmpty()) {
            LOG.log(Level.WARNING, "dnid.file.root no configurado; usando EDAD_THRESHOLD por defecto: {0}", DEFAULT_EDAD_THRESHOLD);
            return DEFAULT_EDAD_THRESHOLD;
        }
        Path configPath = Paths.get(fileRoot, CONFIG_FILENAME);
        // Si el archivo no se encuentra, usar valor por defecto (18)
        if (!Files.isRegularFile(configPath)) {
            LOG.log(Level.WARNING, "Archivo de configuración no encontrado: {0}; usando EDAD_THRESHOLD por defecto: {1}",
                    new Object[]{configPath, DEFAULT_EDAD_THRESHOLD});
            return DEFAULT_EDAD_THRESHOLD;
        }
        // Archivo encontrado: flujo normal (leer y parsear)
        try {
            List<String> lines = Files.readAllLines(configPath, StandardCharsets.UTF_8);
            if (lines == null || lines.isEmpty()) {
                LOG.log(Level.WARNING, "Archivo vacío: {0}; usando EDAD_THRESHOLD por defecto: {1}",
                        new Object[]{configPath, DEFAULT_EDAD_THRESHOLD});
                return DEFAULT_EDAD_THRESHOLD;
            }
            String firstLine = lines.get(0);
            if (firstLine == null) {
                return DEFAULT_EDAD_THRESHOLD;
            }
            String trimmed = firstLine.trim();
            if (trimmed.isEmpty()) {
                LOG.log(Level.WARNING, "Primera línea vacía en {0}; usando EDAD_THRESHOLD por defecto: {1}",
                        new Object[]{configPath, DEFAULT_EDAD_THRESHOLD});
                return DEFAULT_EDAD_THRESHOLD;
            }
            int value = Integer.parseInt(trimmed);
            if (value < 0) {
                LOG.log(Level.WARNING, "Valor negativo en {0}: {1}; usando por defecto: {2}",
                        new Object[]{configPath, value, DEFAULT_EDAD_THRESHOLD});
                return DEFAULT_EDAD_THRESHOLD;
            }
            return value;
        } catch (IOException e) {
            LOG.log(Level.WARNING, e, () -> "Error leyendo " + configPath + "; usando EDAD_THRESHOLD por defecto: " + DEFAULT_EDAD_THRESHOLD);
            return DEFAULT_EDAD_THRESHOLD;
        } catch (NumberFormatException e) {
            LOG.log(Level.WARNING, "Valor no numérico en primera línea de {0}; usando EDAD_THRESHOLD por defecto: {1}",
                    new Object[]{configPath, DEFAULT_EDAD_THRESHOLD});
            return DEFAULT_EDAD_THRESHOLD;
        }
    }
}
