package com.dnid.strategy.impl;

import com.dnid.strategy.DatosNoEncontradosException;
import com.dnid.strategy.DnidProfileStrategy;
import com.dnid.util.ActasConfigLoader;
import com.dnid.util.DatabaseConnection;
import com.dnid.util.ImageCompressionUtil.CompressionResult;
import com.dnid.util.ImageCompressionUtil;
import oracle.jdbc.OracleTypes;

import java.sql.*;
import java.util.*;

/**
 * Estrategia para profile acta_matrimonio: consulta acta de matrimonio por DNI
 * mediante SP_ACTA_MATRIMONIO_BY_DOC. Usa el DataSource JNDI jdbc/desarc.
 * Parámetro: dni.
 */
public class ActaMatrimonioProfileStrategy implements DnidProfileStrategy {

    private static final String CALL_SP = "{call SP_ACTA_MATRIMONIO_BY_DOC(?, ?)}";

    /** Columnas del SELECT de SP_ACTA_MATRIMONIO_BY_DOC; se usan como fallback cuando la línea 2 del CSV no está definida. */
    private static final List<String> DEFAULT_FIELDS_ACTA_MATRIMONIO = Collections.unmodifiableList(Arrays.asList(
            "FE_DE_CELEBRACION",
            "DE_CELEBRADO_LUGAR",
            "tipoDocCONYUGE1",
            "NU_DOC_IDENTIDAD_CTYENTE1",
            "tipoDocCONYUGE2",
            "NU_DOC_IDENTIDAD_CTYENTE2",
            "IMAGEN_ANVERSO",
            "IMAGEN_REVERSO"
    ));

    @Override
    public Map<String, Object> consultar(Map<String, String> params) throws DatosNoEncontradosException, SQLException {
        String dni = params != null ? params.get("dni") : null;
        if (dni == null || dni.trim().isEmpty()) {
            throw new IllegalArgumentException("Parámetro 'dni' requerido para profile acta_matrimonio");
        }
        dni = dni.trim();

        try (Connection conn = DatabaseConnection.getConnectionDesarc();
             CallableStatement cs = conn.prepareCall(CALL_SP)) {
            cs.setString(1, dni);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs == null || !rs.next()) {
                throw new DatosNoEncontradosException("No se encontraron datos de acta de matrimonio para el DNI: " + dni);
            }
            return mapearFila(rs, true);
        }
    }

    private Map<String, Object> mapearFila(ResultSet rs, boolean filterByConfig) throws SQLException {
        Map<String, Object> m = new HashMap<>();
        boolean[] anyConverted = new boolean[]{ false };
        List<String> configFieldsList = ActasConfigLoader.getConfigFieldsListActaMatrimonio();
        if (configFieldsList.isEmpty()) {
            configFieldsList = DEFAULT_FIELDS_ACTA_MATRIMONIO;
        }
        boolean filtrar = filterByConfig && !configFieldsList.isEmpty();
        ResultSetMetaData meta = rs.getMetaData();
        int n = meta.getColumnCount();
        for (int i = 1; i <= n; i++) {
            String col = meta.getColumnLabel(i);
            if (filtrar && configFieldsList.stream().noneMatch(f -> f.equalsIgnoreCase(col))) {
                continue;
            }
            Object val = getObject(rs, meta.getColumnType(i), i, m, col, anyConverted);
            m.put(col, val);
        }
        m.put("was_converted", anyConverted[0]);
        return m;
    }

    private Object getObject(ResultSet rs, int columnType, int index, Map<String, Object> out, String columnName, boolean[] anyConverted) throws SQLException {
        Object o = rs.getObject(index);
        if (rs.wasNull()) return null;
        if (o instanceof Blob) {
            Blob b = (Blob) o;
            byte[] bytes = b.getBytes(1, (int) b.length());
            CompressionResult result = ImageCompressionUtil.toBase64WithPdfConversionAndSizes(bytes);
            if (result.wasConverted) {
                anyConverted[0] = true;
            }
            if (result.reversoBase64 != null) {
                out.put("IMAGEN_ANVERSO", result.base64);
                out.put("IMAGEN_REVERSO", result.reversoBase64);
            }
            return result.base64;
        }
        if (o instanceof Timestamp) {
            return new java.util.Date(((Timestamp) o).getTime());
        }
        if (o instanceof java.sql.Date) {
            return new java.util.Date(((java.sql.Date) o).getTime());
        }
        return o;
    }
}
