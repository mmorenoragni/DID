package com.dnid.strategy.impl;

import com.dnid.strategy.DatosNoEncontradosException;
import com.dnid.strategy.DnidProfileStrategy;
import com.dnid.strategy.FiliacionNegocioException;
import com.dnid.util.ActasConfigLoader;
import com.dnid.util.DatabaseConnection;
import com.dnid.util.ImageCompressionUtil.CompressionResult;
import com.dnid.util.ImageCompressionUtil;
import oracle.jdbc.OracleTypes;

import java.sql.*;
import java.util.*;

/**
 * Estrategia para profile actaNacimientoConFiliacion: consulta acta de nacimiento con filiación
 * por DNI y DNI de filiación. Parámetros: dni, dni_filiacion.
 * Valida titular (mayor de edad, DNI vigente), hijo (menor de edad) y vínculo tutelar.
 */
public class ActaNacimientoConFiliacionProfileStrategy implements DnidProfileStrategy {

    /** SP para obtener datos de persona por DNI (titular/hijo). Ajustar si su BD usa otro nombre. */
    private static final String CALL_SP_DATOS_PERSONA = "{call SP_GET_DATOS_COMPLETO_DNI(?, ?)}";
    private static final String CALL_SP_ACTANACIMIENTO = "{call SP_OBTENER_ACTA_NACIMIENTO(?, ?)}";
    private static final String CLAVE_NUM_DOC_PROGENITOR1 = "NUM_DOC_PROGENITOR1";
    private static final String CLAVE_NUM_DOC_PROGENITOR2 = "NUM_DOC_PROGENITOR2";

    /** Columnas del SELECT del SP de acta de nacimiento; se usan como fallback cuando la línea 3 del CSV no está definida. */
    private static final List<String> DEFAULT_FIELDS_ACTA_NACIMIENTO = Collections.unmodifiableList(Arrays.asList(
            "NU_CUI",
            "DE_PRE_NOMBRES",
            "DE_PRIMER_APELLIDO",
            "DE_SEGUNDO_APELLIDO",
            "FE_NACIMIENTO",
            "vinculoPROGENITOR_1",
            "tipoDocPROGENITOR_1",
            "numDocPROGENITOR_1",
            "vinculoPROGENITOR_2",
            "tipoDocPROGENITOR_2",
            "numDocPROGENITOR_2",
            "IMAGEN_ANVERSO",
            "IMAGEN_REVERSO"
    ));

    private static final String CODIGO_ERROR_FORMATO = "ERROR_FORMATO";
    private static final String CODIGO_ACCESO_DENEGADO = "ACCESO_DENEGADO";
    private static final String CODIGO_ERROR_DNI_CADUCO = "DNI_CADUCO";
    private static final String CODIGO_SIN_FILIACION = "SIN_FILIACION";
    private static final int DEFAULT_EDAD_THRESHOLD = 18;
    private static int EDAD_THRESHOLD = DEFAULT_EDAD_THRESHOLD;

    /**
     * Establece el umbral de edad (mayor de edad) desde configuración externa (p. ej. configuracion_actas.csv).
     * Si value es negativo, se mantiene el valor actual.
     *
     * @param value edad mínima para considerar mayor de edad (típicamente 18)
     */
    public static void setEdadThreshold(int value) {
        if (value >= 0) {
            EDAD_THRESHOLD = value;
        }
    }

    @Override
    public Map<String, Object> consultar(Map<String, String> params) throws DatosNoEncontradosException, SQLException {
        String dni = params != null ? params.get("dni") : null;
        String dniFiliacion = params != null ? params.get("dni_filiacion") : null;
        if (dni == null || dni.trim().isEmpty()) {
            throw new FiliacionNegocioException(CODIGO_ERROR_FORMATO, "Parámetro 'dni' requerido");
        }
        if (dniFiliacion == null || dniFiliacion.trim().isEmpty()) {
            throw new FiliacionNegocioException(CODIGO_ERROR_FORMATO, "Parámetro 'dni_filiacion' requerido");
        }
        dni = dni.trim();
        dniFiliacion = dniFiliacion.trim();

        if (!esNumeroDocumentoValido(dni)) {
            throw new FiliacionNegocioException(CODIGO_ERROR_FORMATO, "Formato de número de documento (dni) no válido");
        }
        if (!esNumeroDocumentoValido(dniFiliacion)) {
            throw new FiliacionNegocioException(CODIGO_ERROR_FORMATO, "Formato de número de documento (dni_filiacion) no válido");
        }

        Map<String, Object> datosDni = buscarEnSP(dni, CALL_SP_DATOS_PERSONA);
        if (datosDni == null) {
            throw new FiliacionNegocioException(CODIGO_ACCESO_DENEGADO, "Titular no encontrado");
        }

        if (esDniCaduco(datosDni)) {
            throw new FiliacionNegocioException(CODIGO_ERROR_DNI_CADUCO, "DNI del titular caduco");
        }

        if (!esMayorDeEdad(datosDni)) {
            throw new FiliacionNegocioException(CODIGO_ACCESO_DENEGADO, "El titular no es mayor de edad");
        }

        Map<String, Object> datosFiliacion = buscarEnSP(dniFiliacion, CALL_SP_DATOS_PERSONA);
        if (datosFiliacion == null) {
            throw new FiliacionNegocioException(CODIGO_ACCESO_DENEGADO, "Datos del hijo/a no encontrados");
        }

        if (!esMenorDeEdad(datosFiliacion)) {
            throw new FiliacionNegocioException(CODIGO_ACCESO_DENEGADO, "El hijo/a no es menor de edad");
        }

        if (!tienenRelacionFamiliar(dni, datosFiliacion)) {
            throw new FiliacionNegocioException(CODIGO_SIN_FILIACION, "No existe vínculo tutelar entre titular e hijo/a");
        }

        try (Connection conn = DatabaseConnection.getConnectionDesarc();
             CallableStatement cs = conn.prepareCall(CALL_SP_ACTANACIMIENTO)) {
            cs.setString(1, dniFiliacion);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();

            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs == null || !rs.next()) {
                throw new DatosNoEncontradosException("No se encontraron datos de acta de nacimiento con filiación para DNI: " + dni + ", dni_filiacion: " + dniFiliacion);
            }
            return mapearFila(rs, true);
        }
    }

    private static boolean esNumeroDocumentoValido(String dni) {
        if (dni == null) return false;
        if (dni.length() != 8) return false;
        for (int i = 0; i < dni.length(); i++) {
            if (!Character.isDigit(dni.charAt(i))) return false;
        }
        return true;
    }

    private Map<String, Object> buscarEnSP(String dni, String callSp) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnectionDesadni();
             CallableStatement cs = conn.prepareCall(callSp)) {
            cs.setString(1, dni);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs != null && rs.next()) {
                return mapearFila(rs, false);
            }
        }
        return null;
    }

    private Map<String, Object> buscarEnSPDesaRc(String dniFiliacion, String callSp) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnectionDesarc();
             CallableStatement cs = conn.prepareCall(callSp)) {
            cs.setString(1, dniFiliacion);
            cs.registerOutParameter(2, OracleTypes.CURSOR);
            cs.execute();
            ResultSet rs = (ResultSet) cs.getObject(2);
            if (rs != null && rs.next()) {
                return mapearFila(rs, false);
            }
        }
        return null;
    }

    private static boolean esDniCaduco(Map<String, Object> datosDni) {
        Object v = datosDni != null ? datosDni.get("FECHA_CADUCIDAD") : null;
        if (v == null) v = datosDni != null ? datosDni.get("FECHA_CADUCIDAD_DNI") : null;
        if (v == null) return false;
        java.util.Date fechaCaducidad = v instanceof java.util.Date ? (java.util.Date) v : null;
        if (fechaCaducidad == null && v instanceof java.sql.Date) {
            fechaCaducidad = new java.util.Date(((java.sql.Date) v).getTime());
        }
        return fechaCaducidad != null && fechaCaducidad.before(new java.util.Date(System.currentTimeMillis()));
    }

    private static boolean esMayorDeEdad(Map<String, Object> datosDni) {
        Object v = datosDni != null ? datosDni.get("FECHA_NACIMIENTO") : null;
        if (v == null) v = datosDni != null ? datosDni.get("FECHA_NAC") : null;
        if (v == null) return false;
        java.util.Date fechaNac = v instanceof java.util.Date ? (java.util.Date) v : null;
        if (fechaNac == null && v instanceof java.sql.Date) {
            fechaNac = new java.util.Date(((java.sql.Date) v).getTime());
        }
        if (fechaNac == null) return false;
        long edadMillis = System.currentTimeMillis() - fechaNac.getTime();
        int años = (int) (edadMillis / (365.25 * 24 * 60 * 60 * 1000));
        return años >= EDAD_THRESHOLD;
    }

    private static boolean esMenorDeEdad(Map<String, Object> datosFiliacion) {
        return !esMayorDeEdad(datosFiliacion);
    }

    private static boolean tienenRelacionFamiliar(String dni, Map<String, Object> datosFiliacion) {
        String pro1 = stringValue(datosFiliacion.get(CLAVE_NUM_DOC_PROGENITOR1));
        String pro2 = stringValue(datosFiliacion.get(CLAVE_NUM_DOC_PROGENITOR2));
        return dni.equals(pro1) || dni.equals(pro2);
    }

    private static String getString(Map<String, Object> m, String key) {
        Object v = m.get(key);
        if (v == null) return null;
        String s = v.toString().trim();
        return s.isEmpty() ? null : s;
    }

    private Map<String, Object> mapearFila(ResultSet rs, boolean filterByConfig) throws SQLException {
        Map<String, Object> m = new HashMap<>();
        boolean[] anyConverted = new boolean[]{ false };
        List<String> configFieldsList = ActasConfigLoader.getConfigFieldsListActaNacimiento();
        if (configFieldsList.isEmpty()) {
            configFieldsList = DEFAULT_FIELDS_ACTA_NACIMIENTO;
        }
        boolean filtrar = filterByConfig && !configFieldsList.isEmpty();
        ResultSetMetaData meta = rs.getMetaData();
        int n = meta.getColumnCount();
        for (int i = 1; i <= n; i++) {
            String col = meta.getColumnLabel(i);
            if (filtrar && configFieldsList.stream().noneMatch(f -> f.equalsIgnoreCase(col))) {
                continue;
            }
            Object val = getObject(rs, meta.getColumnType(i), i, m, col, anyConverted);
            m.put(col, val);
        }
        m.put("was_converted", anyConverted[0]);
        return m;
    }

    private Object getObject(ResultSet rs, int columnType, int index, Map<String, Object> out, String columnName, boolean[] anyConverted) throws SQLException {
        Object o = rs.getObject(index);
        if (rs.wasNull()) return null;
        if (o instanceof Blob) {
            Blob b = (Blob) o;
            byte[] bytes = b.getBytes(1, (int) b.length());
            CompressionResult result = ImageCompressionUtil.toBase64WithPdfConversionAndSizes(bytes);
            if (result.wasConverted) {
                anyConverted[0] = true;
            }
            if (result.reversoBase64 != null) {
                out.put("IMAGEN_ANVERSO", result.base64);
                out.put("IMAGEN_REVERSO", result.reversoBase64);
            }
            return result.base64;
        }
        if (o instanceof Timestamp) {
            return new java.util.Date(((Timestamp) o).getTime());
        }
        if (o instanceof java.sql.Date) {
            return new java.util.Date(((java.sql.Date) o).getTime());
        }
        return o;
    }

    private static String stringValue(Object o) {
        if (o == null) return "";
        return String.valueOf(o).trim();
    }
}
