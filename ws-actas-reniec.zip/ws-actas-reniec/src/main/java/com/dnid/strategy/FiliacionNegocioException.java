package com.dnid.strategy;

/**
 * Excepción de negocio para validaciones de filiación (formato, acceso denegado,
 * DNI caduco, sin vínculo tutelar). Incluye código para que el cliente pueda
 * interpretar el error. El servlet la traduce en respuesta JSON con codigo y error.
 */
public class FiliacionNegocioException extends RuntimeException {

    private final String codigo;

    public FiliacionNegocioException(String codigo, String mensaje) {
        super(mensaje);
        this.codigo = codigo;
    }

    public FiliacionNegocioException(String codigo, String mensaje, Throwable cause) {
        super(mensaje, cause);
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }
}
