package com.dnid.strategy;

import java.sql.SQLException;
import java.util.Map;

/**
 * Estrategia de consulta de información de identidad digital (DNID).
 * Cada implementación corresponde a un valor de parámetro "profile" (p. ej. ACTA_NACIMIENTO).
 */
public interface DnidProfileStrategy {

    /**
     * Ejecuta la consulta según los parámetros recibidos y devuelve el mapa a serializar como JSON.
     *
     * @param params parámetros del request (profile, dni, acta_nacimiento, etc.)
     * @return mapa con los datos a devolver (nunca null)
     * @throws DatosNoEncontradosException si no hay datos para la consulta
     * @throws SQLException si ocurre un error de base de datos
     * @throws IllegalArgumentException si faltan parámetros requeridos
     */
    Map<String, Object> consultar(Map<String, String> params) throws DatosNoEncontradosException, SQLException;
}
