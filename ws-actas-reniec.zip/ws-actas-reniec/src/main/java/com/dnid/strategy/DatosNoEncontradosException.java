package com.dnid.strategy;

/**
 * Excepción lanzada cuando la estrategia no encuentra datos para la consulta.
 * El servlet la traduce en respuesta HTTP 404.
 */
public class DatosNoEncontradosException extends Exception {

    public DatosNoEncontradosException(String message) {
        super(message);
    }

    public DatosNoEncontradosException(String message, Throwable cause) {
        super(message, cause);
    }
}
