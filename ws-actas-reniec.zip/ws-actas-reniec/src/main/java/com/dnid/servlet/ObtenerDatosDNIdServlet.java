package com.dnid.servlet;

import com.dnid.strategy.DatosNoEncontradosException;
import com.dnid.strategy.DnidProfileStrategy;
import com.dnid.strategy.FiliacionNegocioException;
import com.dnid.strategy.impl.ActaMatrimonioProfileStrategy;
import com.dnid.strategy.impl.ActaNacimientoProfileStrategy;
import com.dnid.strategy.impl.ActaNacimientoConFiliacionProfileStrategy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Servlet que expone POST /ObtenerDatosDNId para consultar datos de identidad digital.
 * El parámetro "profile" selecciona la estrategia (p. ej. ACTA_NACIMIENTO, ACTA_MATRIMONIO). Cada estrategia define cómo buscar y devolver la información.
 */
public class ObtenerDatosDNIdServlet extends HttpServlet {

    private static final String CONTENT_TYPE_JSON = "application/json; charset=UTF-8";

    /** Logger para peticiones entrantes; visible en WebLogic (JUL). */
    private static final Logger LOG = Logger.getLogger(ObtenerDatosDNIdServlet.class.getName());

    /** Estrategias por profile (clave normalizada en mayúsculas). */
    private final Map<String, DnidProfileStrategy> strategies = new HashMap<>();

    @Override
    public void init() throws ServletException {
        super.init();
        strategies.put("ACTA_NACIMIENTO", new ActaNacimientoProfileStrategy());
        strategies.put("ACTA_MATRIMONIO", new ActaMatrimonioProfileStrategy());
        strategies.put("ACTA_NACIMIENTO_FILIACION", new ActaNacimientoConFiliacionProfileStrategy());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setContentType(CONTENT_TYPE_JSON);

        Map<String, String> params = obtenerParametrosDesdeRequest(req);
        LOG.log(Level.INFO, "[ObtenerDatosDNId] Petición entrante - profile: {0}, parámetros: {1}",
                new Object[]{params.get("profile"), params});

        String profile = params.get("profile");
        if (profile == null || profile.trim().isEmpty()) {
            enviarError(resp, HttpServletResponse.SC_BAD_REQUEST, "Parámetro 'profile' requerido");
            return;
        }
        String profileKey = profile.trim().toUpperCase();
        DnidProfileStrategy strategy = strategies.get(profileKey);
        if (strategy == null) {
            enviarError(resp, HttpServletResponse.SC_BAD_REQUEST, "Profile no soportado: " + profile);
            return;
        }

        try {
            Map<String, Object> datos = strategy.consultar(params);
            Gson gson = new GsonBuilder().setDateFormat("dd/MM/yyyy").create();
            String json = gson.toJson(datos);
            resp.setStatus(HttpServletResponse.SC_OK);
            PrintWriter out = resp.getWriter();
            out.print(json);
            out.flush();
        } catch (DatosNoEncontradosException e) {
            enviarError(resp, HttpServletResponse.SC_NOT_FOUND, e.getMessage());
        } catch (FiliacionNegocioException e) {
            int status = "ERROR_FORMATO".equals(e.getCodigo()) ? HttpServletResponse.SC_BAD_REQUEST : HttpServletResponse.SC_FORBIDDEN;
            enviarErrorFiliacion(resp, status, e.getCodigo(), e.getMessage());
        } catch (IllegalArgumentException e) {
            enviarError(resp, HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            String detalle = e.getMessage();
            if (e.getCause() != null && e.getCause().getMessage() != null) {
                detalle = detalle + " | Causa: " + e.getCause().getMessage();
            }
            enviarError(resp, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al consultar datos: " + detalle);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType(CONTENT_TYPE_JSON);
        resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        PrintWriter out = resp.getWriter();
        out.print("{\"error\":\"Método no permitido. Use POST con parámetro profile (ej. DNI) y parámetros según el profile.\"}");
        out.flush();
    }

    /**
     * Obtiene parámetros del request: por form o por JSON body.
     * Incluye: profile, dni, dni_filiacion, acta_nacimiento.
     */
    private Map<String, String> obtenerParametrosDesdeRequest(HttpServletRequest req) throws IOException {
        Map<String, String> out = new HashMap<>();
        String contentType = req.getContentType();
        if (contentType != null && (contentType.contains("application/json"))) {
            try (Scanner sc = new Scanner(req.getInputStream(), StandardCharsets.UTF_8.name()).useDelimiter("\\A")) {
                String body = sc.hasNext() ? sc.next() : "";
                if (!body.isEmpty()) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> map = new Gson().fromJson(body, Map.class);
                    if (map != null) {
                        if (map.containsKey("profile")) out.put("profile", String.valueOf(map.get("profile")));
                        if (map.containsKey("dni")) out.put("dni", String.valueOf(map.get("dni")));
                        if (map.containsKey("dni_filiacion")) out.put("dni_filiacion", String.valueOf(map.get("dni_filiacion")));
                        if (map.containsKey("acta_nacimiento")) out.put("acta_nacimiento", String.valueOf(map.get("acta_nacimiento")));
                    }
                }
            }
        } else {
            String profile = req.getParameter("profile");
            String dni = req.getParameter("dni");
            String dniFiliacion = req.getParameter("dni_filiacion");
            String actaNacimiento = req.getParameter("acta_nacimiento");
            if (profile != null) out.put("profile", profile);
            if (dni != null) out.put("dni", dni);
            if (dniFiliacion != null) out.put("dni_filiacion", dniFiliacion);
            if (actaNacimiento != null) out.put("acta_nacimiento", actaNacimiento);
        }
        return out;
    }

    private void enviarError(HttpServletResponse resp, int status, String mensaje) throws IOException {
        resp.setStatus(status);
        Map<String, String> err = new HashMap<>();
        err.put("error", mensaje);
        PrintWriter out = resp.getWriter();
        out.print(new Gson().toJson(err));
        out.flush();
    }

    private void enviarErrorFiliacion(HttpServletResponse resp, int status, String codigo, String mensaje) throws IOException {
        resp.setStatus(status);
        Map<String, String> err = new HashMap<>();
        err.put("codigo", codigo);
        err.put("error", mensaje);
        PrintWriter out = resp.getWriter();
        out.print(new Gson().toJson(err));
        out.flush();
    }

}
