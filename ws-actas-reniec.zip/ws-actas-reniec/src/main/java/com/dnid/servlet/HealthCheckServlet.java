package com.dnid.servlet;

import com.dnid.util.DatabaseConnection;
import com.dnid.util.FileRootResolver;
import com.google.gson.Gson;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.util.Comparator;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Health check por GET: reporta el estado de las conexiones JNDI jdbc/desarc y jdbc/desadni.
 */
public class HealthCheckServlet extends HttpServlet {

    private static final String CONTENT_TYPE_JSON = "application/json; charset=UTF-8";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setContentType(CONTENT_TYPE_JSON);

        Map<String, Object> body = new LinkedHashMap<>();
        Map<String, Map<String, String>> connections = new LinkedHashMap<>();

        connections.put("jdbc/desarc", checkDesarc());
        connections.put("jdbc/desadni", checkDesadni());

        body.put("connections", connections);

        boolean allUp = "UP".equals(connections.get("jdbc/desarc").get("status"))
                && "UP".equals(connections.get("jdbc/desadni").get("status"));
        body.put("status", allUp ? "UP" : "DOWN");

        String fileRootParam = getServletContext().getInitParameter("dnid.file.root");
        String fileRootResolved = FileRootResolver.resolve(fileRootParam);
        body.put("fileRoot", fileRootResolved);
        body.put("fileRootFiles", listFileRootFiles(fileRootResolved));

        Map<String, List<String>> paths = listAbsoluteAndRelativePaths(fileRootResolved);
        body.put("absolutePaths", paths.get("absolutePaths"));
        body.put("relativePaths", paths.get("relativePaths"));

        String json = new Gson().toJson(body);
        resp.setStatus(allUp ? HttpServletResponse.SC_OK : HttpServletResponse.SC_SERVICE_UNAVAILABLE);
        PrintWriter out = resp.getWriter();
        out.print(json);
        out.flush();
    }

    private static Map<String, String> checkDesarc() {
        Map<String, String> result = new LinkedHashMap<>();
        result.put("name", "jdbc/desarc");
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnectionDesarc();
            result.put("status", "UP");
        } catch (SQLException e) {
            result.put("status", "DOWN");
            result.put("message", e.getMessage());
        } finally {
            DatabaseConnection.closeConnection(conn);
        }
        return result;
    }

    private static Map<String, String> checkDesadni() {
        Map<String, String> result = new LinkedHashMap<>();
        result.put("name", "jdbc/desadni");
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnectionDesadni();
            result.put("status", "UP");
        } catch (SQLException e) {
            result.put("status", "DOWN");
            result.put("message", e.getMessage());
        } finally {
            DatabaseConnection.closeConnection(conn);
        }
        return result;
    }

    /**
     * Construye las listas de rutas absolutas y relativas del directorio fileRoot y sus archivos.
     * Posición 0 = directorio (absoluta: fileRoot, relativa: "."); resto = archivos ordenados por nombre.
     *
     * @param fileRootAbs ruta absoluta del directorio (puede ser null)
     * @return mapa con claves "absolutePaths" y "relativePaths"; listas vacías si fileRoot es null o no es directorio
     */
    private Map<String, List<String>> listAbsoluteAndRelativePaths(String fileRootAbs) {
        List<String> absolutePaths = new ArrayList<>();
        List<String> relativePaths = new ArrayList<>();
        if (fileRootAbs == null || fileRootAbs.isEmpty()) {
            return buildPathsResult(absolutePaths, relativePaths);
        }
        Path dir = Paths.get(fileRootAbs);
        if (!Files.isDirectory(dir)) {
            return buildPathsResult(absolutePaths, relativePaths);
        }
        absolutePaths.add(fileRootAbs);
        relativePaths.add(".");
        try (Stream<Path> stream = Files.list(dir)) {
            List<Path> files = new ArrayList<>();
            stream.filter(Files::isRegularFile).forEach(files::add);
            files.sort(Comparator.comparing(p -> p.getFileName().toString()));
            for (Path p : files) {
                absolutePaths.add(p.toAbsolutePath().normalize().toString());
                relativePaths.add(p.getFileName().toString());
            }
        } catch (IOException e) {
            // directorio ya añadido; archivos pueden quedar vacíos
        }
        return buildPathsResult(absolutePaths, relativePaths);
    }

    private static Map<String, List<String>> buildPathsResult(List<String> absolutePaths, List<String> relativePaths) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        result.put("absolutePaths", absolutePaths);
        result.put("relativePaths", relativePaths);
        return result;
    }

    /**
     * Lista los nombres de los archivos (y solo archivos, no subdirectorios) en el directorio fileRoot.
     *
     * @param fileRootAbs ruta absoluta del directorio (puede ser null)
     * @return lista de nombres de archivo, ordenada; lista vacía si fileRoot es null, no existe o no es directorio
     */
    private List<String> listFileRootFiles(String fileRootAbs) {
        if (fileRootAbs == null || fileRootAbs.isEmpty()) {
            return Collections.emptyList();
        }
        Path dir = Paths.get(fileRootAbs);
        if (!Files.isDirectory(dir)) {
            return Collections.emptyList();
        }
        try (Stream<Path> stream = Files.list(dir)) {
            List<String> names = new ArrayList<>();
            stream.filter(Files::isRegularFile)
                    .map(p -> p.getFileName().toString())
                    .forEach(names::add);
            Collections.sort(names);
            return names;
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }
}
