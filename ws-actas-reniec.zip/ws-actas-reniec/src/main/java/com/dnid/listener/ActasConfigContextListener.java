package com.dnid.listener;

import com.dnid.strategy.impl.ActaNacimientoConFiliacionProfileStrategy;
import com.dnid.util.ActasConfigLoader;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Carga la configuración de actas (configuracion_actas.csv) al arranque de la aplicación
 * e inicializa EDAD_THRESHOLD en ActaNacimientoConFiliacionProfileStrategy.
 */
public class ActasConfigContextListener implements ServletContextListener {

    private static final Logger LOG = Logger.getLogger(ActasConfigContextListener.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        int edadThreshold = ActasConfigLoader.loadEdadThreshold(sce.getServletContext());
        ActaNacimientoConFiliacionProfileStrategy.setEdadThreshold(edadThreshold);
        LOG.log(Level.INFO, "Configuración actas cargada: EDAD_THRESHOLD={0}", edadThreshold);

        // Línea 2 (índice 1) = campos para ActaMatrimonio
        List<String> configFieldsActaMatrimonio = ActasConfigLoader.loadConfigFieldsListAt(sce.getServletContext(), 1);
        ActasConfigLoader.setConfigFieldsListActaMatrimonio(configFieldsActaMatrimonio);
        LOG.log(Level.INFO, "configFieldsList ActaMatrimonio (línea 2) cargada: {0} campos", configFieldsActaMatrimonio.size());

        // Línea 3 (índice 2) = campos para ActaNacimiento y ActaNacimientoConFiliacion
        List<String> configFieldsActaNacimiento = ActasConfigLoader.loadConfigFieldsListAt(sce.getServletContext(), 2);
        ActasConfigLoader.setConfigFieldsListActaNacimiento(configFieldsActaNacimiento);
        LOG.log(Level.INFO, "configFieldsList ActaNacimiento (línea 3) cargada: {0} campos", configFieldsActaNacimiento.size());
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Nada que liberar
    }
}
