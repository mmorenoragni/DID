# Proyecto WS-ACTAS-RENIEC

Aplicación web Java para consultar actas de nacimiento desde Oracle Database mediante procedimientos almacenados.

## Tecnologías

- **Java 8**
- **Java EE 7** (Servlets)
- **Oracle Database Free** (Docker)
- **Oracle JDBC Driver**
- **Maven**
- **WebLogic 12c**

## Estructura del Proyecto

```
ws-actas-dnid/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/dnid/
│       │       ├── servlet/
│       │       │   ├── HolaMundoServlet.java
│       │       │   ├── ActaNacimientoServlet.java
│       │       │   └── ActaImagenServlet.java
│       │       ├── model/
│       │       │   └── ActaNacimiento.java
│       │       └── util/
│       │           └── DatabaseConnection.java
│       └── webapp/
│           ├── WEB-INF/
│           │   ├── web.xml
│           │   └── weblogic.xml
│           └── index.jsp
├── sql/
│   ├── 00_all_in_one.sql
│   └── ...
└── pom.xml
```

## Configuración

### Base de Datos Oracle (JNDI)

La aplicación obtiene la conexión a Oracle mediante **JNDI**. El DataSource debe estar configurado en WebLogic con el nombre JNDI **`jdbc/desarc`**.

**Configurar el DataSource en WebLogic:**

1. En la consola de administración: **Servicios** → **Orígenes de datos** → **Nuevo** → **Origen de datos genérico**.
2. Nombre: `DesarcDS` (o el que prefieras; debe coincidir con el JNDI en `weblogic.xml`).
3. JNDI Name: `jdbc/desarc`.
4. Driver: **Oracle's Driver (Thin) for Service IDs**.
5. Propiedades de conexión (según tu entorno, por ejemplo para Oracle en Docker):
   - **URL**: `jdbc:oracle:thin:@localhost:1521/FREEPDB1`
   - **Usuario**: `system`
   - **Contraseña**: `oracle`
6. Asignar el DataSource al servidor/cluster donde se despliega la aplicación.
7. Activar los cambios.

Si el JNDI en WebLogic es distinto de `jdbc/desarc`, edita el elemento `<jndi-name>` en `WEB-INF/weblogic.xml`.

### Compilación

```bash
mvn clean package
```

El archivo WAR se generará en `target/ws-actas-dnid.war`

## Endpoints Disponibles

### 1. Consultar Acta de Nacimiento (JSON)

**URL**: `/ws-actas-dnid/acta-nacimiento`

**Método**: GET

**Parámetros**:
- `nu_acta` (requerido): Número del acta de nacimiento
- `format` (opcional): Formato de respuesta (`json` o `html`, por defecto `json`)

**Ejemplo**:
```
GET /ws-actas-dnid/acta-nacimiento?nu_acta=1001
GET /ws-actas-dnid/acta-nacimiento?nu_acta=1001&format=html
```

**Respuesta JSON**:
```json
{
  "nuCui": "12345678",
  "nombres": "JUAN CARLOS",
  "primerApellido": "PEREZ",
  "segundoApellido": "GARCIA",
  "nombreCompleto": "JUAN CARLOS PEREZ GARCIA",
  "fechaNacimiento": "1990-05-15",
  "progenitor1": {
    "vinculo": "PADRE",
    "tipoDocumento": "DNI",
    "numeroDocumento": "87654321"
  },
  "progenitor2": {
    "vinculo": "MADRE",
    "tipoDocumento": "DNI",
    "numeroDocumento": "11223344"
  },
  "tieneImagenAnverso": true,
  "tieneImagenReverso": true
}
```

### 2. Obtener Imagen del Acta

**URL**: `/ws-actas-dnid/acta-imagen`

**Método**: GET

**Parámetros**:
- `nu_acta` (requerido): Número del acta de nacimiento
- `lado` (requerido): `anverso` o `reverso`

**Ejemplo**:
```
GET /ws-actas-dnid/acta-imagen?nu_acta=1001&lado=anverso
GET /ws-actas-dnid/acta-imagen?nu_acta=1001&lado=reverso
```

**Respuesta**: Imagen JPEG

### 3. Página de Prueba

**URL**: `/ws-actas-dnid/test`

**Método**: GET

Muestra información básica del servidor WebLogic.

## Procedimiento Almacenado

El servlet utiliza el procedimiento almacenado `SP_ACTA_NACIMIENTO` del esquema `IDORRCC`:

```sql
SP_ACTA_NACIMIENTO(
    p_nu_acta IN NUMBER,
    p_recordset OUT SYS_REFCURSOR
)
```

## Despliegue en WebLogic

1. Compilar el proyecto:
   ```bash
   mvn clean package
   ```

2. Desplegar el WAR en WebLogic:
   - Acceder a la consola de administración
   - Ir a "Despliegues"
   - Seleccionar "Instalar" o "Actualizar"
   - Subir el archivo `target/ws-actas-dnid.war`

3. Verificar el despliegue:
   - Acceder a: `http://localhost:7001/ws-actas-dnid/test`
   - Probar el endpoint: `http://localhost:7001/ws-actas-dnid/acta-nacimiento?nu_acta=1001`

## Base de Datos

Los scripts SQL se encuentran en el directorio `sql/`. Ver `sql/README.md` para más detalles.

### Ejecutar Scripts

Si usas Docker Compose, los scripts se ejecutan automáticamente al iniciar el contenedor.

Para ejecutar manualmente:
```bash
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_all_in_one.sql
```

## Solución de Problemas

### Error: "ClassNotFoundException: javax.servlet.http.HttpServlet"
- Verificar que el `weblogic.xml` no tenga `prefer-application-packages` para servlets
- Asegurarse de que las dependencias tengan `scope provided`

### Error: "Unmarshaller failed"
- Verificar que existe el archivo `weblogic.xml`
- Revisar que el `web.xml` use el namespace correcto

### Error de conexión a la base de datos
- Verificar que el DataSource JNDI `jdbc/desarc` esté creado y activo en WebLogic.
- Comprobar que el JNDI en `weblogic.xml` coincida con el configurado en la consola.
- Verificar que Oracle esté accesible desde el servidor WebLogic (host, puerto, usuario, contraseña del DataSource).

## Licencia

Este proyecto es de uso interno.
