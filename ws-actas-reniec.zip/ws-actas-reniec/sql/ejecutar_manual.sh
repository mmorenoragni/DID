#!/bin/bash

# Script para ejecutar los scripts SQL manualmente
# Uso: ./ejecutar_manual.sh

echo "=========================================="
echo "Ejecutando scripts SQL en Oracle Database"
echo "=========================================="
echo ""

# Verificar que el contenedor esté ejecutándose
if ! docker ps | grep -q oracle-free; then
    echo "❌ Error: El contenedor 'oracle-free' no está ejecutándose"
    echo "   Por favor, inicia el contenedor con: docker-compose up -d"
    exit 1
fi

echo "✓ Contenedor Oracle encontrado"
echo ""

# Verificar estado actual
echo "Verificando estado actual de la base de datos..."
docker exec -i oracle-free sqlplus -s system/oracle@FREEPDB1 <<EOF
SET PAGESIZE 0
SET FEEDBACK OFF
SELECT CASE WHEN COUNT(*) > 0 THEN 'Usuario IDORRCC existe' ELSE 'Usuario IDORRCC NO existe' END
FROM ALL_USERS WHERE USERNAME = 'IDORRCC';
EXIT;
EOF

echo ""
read -p "¿Deseas continuar con la ejecución de los scripts? (s/n): " respuesta

if [[ ! $respuesta =~ ^[Ss]$ ]]; then
    echo "Operación cancelada."
    exit 0
fi

echo ""
echo "Ejecutando script completo..."
echo ""

# Ejecutar el script completo
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_all_in_one.sql

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✓ Scripts ejecutados correctamente"
    echo "=========================================="
    echo ""
    echo "Verificando instalación..."
    docker exec -i oracle-free sqlplus -s system/oracle@FREEPDB1 @sql/verificar_instalacion.sql
else
    echo ""
    echo "❌ Error al ejecutar los scripts"
    exit 1
fi
