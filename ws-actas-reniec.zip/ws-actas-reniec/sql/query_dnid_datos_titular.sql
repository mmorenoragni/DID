-- =============================================================================
-- Query DNI Digital - Estructura JSON: datosDNI + titular
-- Oracle 11g - Para consulta de DNI digital (IDOTABMAESTRA, IMAGADM)
-- Ajustar nombres de columnas de GETM_ANI según el modelo real.
-- =============================================================================

SELECT
    -- ---------- datosDNI ----------
    LPAD(TRIM(TO_CHAR(a.NU_DNI)), 8, '0')                     AS nuTarjeta,
    TO_CHAR(a.FE_EMISION, 'YYYYMMDD')                         AS feEmision,
    CASE WHEN EXTRACT(YEAR FROM a.FE_CADUCIDAD) = 3000 THEN NULL
         ELSE TO_CHAR(a.FE_CADUCIDAD, 'YYYYMMDD') END         AS feVencimiento,
    '3'                                                       AS versionDNI,
    CASE WHEN res.NU_DNI IS NOT NULL AND UPPER(NVL(TRIM(res.DE_CEL), 'X')) LIKE '%FALLECIDO%' THEN 'FALLECIDO'
         WHEN res.NU_DNI IS NOT NULL THEN NVL(TRIM(res.DE_CEL), 'VIGENTE')
         ELSE 'VIGENTE' END                                   AS deEstadoDNI,

    -- ---------- titular ----------
    LPAD(TRIM(TO_CHAR(a.NU_DNI)), 8, '0')                     AS dni,
    TRIM(a.PRENOM_INSCRITO)                                   AS prenombres,
    TRIM(a.AP_PRIMER)                                         AS primerApellido,
    TRIM(a.AP_SEGUNDO)                                        AS segundoApellido,
    TO_CHAR(a.FE_NACIMIENTO, 'YYYYMMDD')                      AS feNacimiento,
    TRIM(REPLACE(
        COALESCE(ubigeo_nac.DE_UBIGEO_CAPTU,
                 TRIM(cont_nac.DE_DOM) || ' / ' || TRIM(pais_nac.DE_DOM)),
        '/', ' / ')) AS deLugarNacimiento,
    TRIM(a.DE_GENERO)                                         AS sexo,
    COALESCE(ec.DE_ESTADO_CIVIL, a.DE_ESTADO_CIVIL)           AS estadoCivil,
    COALESCE(img_mayor.IM_FOTO, img_menor.IM_FOTO_MENOR)      AS foto,
    img_mayor.IM_HUELLA                                       AS huellaDigital,
    TRIM(
        NVL(TRIM(dec_pref_dir.DE_DOM), '') || ' ' ||
        NVL(TRIM(a.DE_DIRECCION), '') || ' ' ||
        NVL(TRIM(TO_CHAR(a.NU_DIRECCION)), '') || ' ' ||
        NVL(TRIM(dec_pref_block.DE_DOM), '') || ' ' ||
        NVL(TRIM(a.DE_BLOCK_CHALET), '') || ' ' ||
        NVL(TRIM(dec_pref_int.DE_DOM), '') || ' ' ||
        NVL(TRIM(a.DE_INTERIOR), '') || ' ' ||
        NVL(TRIM(dec_pref_urb.DE_DOM), '') || ' ' ||
        NVL(TRIM(a.DE_URBANIZACION), '') || ' ' ||
        NVL(TRIM(a.DE_ETAPA), '') || ' ' ||
        NVL(TRIM(a.DE_MANZANA), '') || ' ' ||
        NVL(TRIM(a.DE_LOTE_DIRECCION), '')
    )                                                         AS domicilio,
    NVL(nac.DE_DOM, 'PERUANO')                                AS nacionalidad,
    NVL(donacion.DE_DOM, 'Si')                                AS donacionOrganos,
    TRIM(COALESCE(cp_nac.DE_DOM, ubigeo_nac.DE_CUARTO_NIVEL, a.CO_CENTRO_POBLADO_NACI)) AS cuartoNivel

FROM
    IDOTABMAESTRA.GETM_ANI a

-- Ubigeo nacimiento: GETM_ANI no tiene CO_UBIGEO_NACIMIENTO; se arma con CO_DEPARTAMENTO_NACI, CO_PROVINCIA_NACI, CO_DISTRITO_NACI (6 dígitos)
LEFT JOIN IDOTABMAESTRA.GEVW_UBIGEO ubigeo_nac
    ON ubigeo_nac.CO_UBIGEO = REPLACE(
           LPAD(NVL(TRIM(TO_CHAR(a.CO_DEPARTAMENTO_NACI)), '0'), 2, '0') ||
           LPAD(NVL(TRIM(TO_CHAR(a.CO_PROVINCIA_NACI)), '0'), 2, '0') ||
           LPAD(NVL(TRIM(TO_CHAR(a.CO_DISTRITO_NACI)), '0'), 2, '0'),
           '-', '')

-- Extranjeros: continente y país de nacimiento (catálogos por código; ajustar nombres de dominio/tabla)
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS cont_nac
    ON cont_nac.CO_DOMINIO = 'CONTINENTE' AND cont_nac.CO_DOM = a.CO_CONTINENTE_NACI
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS pais_nac
    ON pais_nac.CO_DOMINIO = 'PAIS' AND pais_nac.CO_DOM = a.CO_PAIS_NACI

-- Cuarto nivel: centro poblado de nacimiento (ajustar tabla/dominio si existe GETR_CENTRO_POBLADO)
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS cp_nac
    ON cp_nac.CO_DOMINIO = 'CENTRO_POBLADO' AND cp_nac.CO_DOM = a.CO_CENTRO_POBLADO_NACI

-- Sexo: GETM_ANI solo tiene DE_GENERO (descripción), no CO_GENERO; no se cruza con GETR_DOMINIOS.

-- Estado civil
LEFT JOIN IDOTABMAESTRA.GETR_ESTADO_CIVIL ec
    ON ec.CO_ESTADO_CIVIL = a.CO_ESTADO_CIVIL

-- Domicilio: prefijos desde GETR_DOMINIOS (DECODE = CO_DOM -> DE_DOM, REPLACE/TRIM según doc)
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS dec_pref_dir
    ON dec_pref_dir.CO_DOMINIO = 'DE_PREF_DIRECCION' AND dec_pref_dir.CO_DOM = a.CO_PREF_DIRECCION
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS dec_pref_block
    ON dec_pref_block.CO_DOMINIO = 'DE_PREF_BLOCK' AND dec_pref_block.CO_DOM = a.CO_PREF_BLOCK
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS dec_pref_int
    ON dec_pref_int.CO_DOMINIO = 'DE_PREF_INTERIOR' AND dec_pref_int.CO_DOM = a.CO_PREF_INTERIOR
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS dec_pref_urb
    ON dec_pref_urb.CO_DOMINIO = 'DE_PREF_URB' AND dec_pref_urb.CO_DOM = a.CO_PREF_URB

-- Nacionalidad (dominio NACIONALIDAD si existe)
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS nac
    ON nac.CO_DOMINIO = 'NACIONALIDAD' AND nac.CO_DOM = a.CO_NACIONALIDAD

-- Donación de órganos (dominio si existe)
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS donacion
    ON donacion.CO_DOMINIO = 'DONACION_ORGANOS' AND donacion.CO_DOM = a.CO_DONACION_ORGANOS

-- Restricción (DE_CEL con DECODES -> FALLECIDO, etc.)
LEFT JOIN IDOTABMAESTRA.GETM_RESTRICCION res
    ON res.NU_DNI = a.NU_DNI

-- Foto y huella: IMAGADM (cruzar por TIPO y NRO FICHA IMAGEN o NU_FORMULARIO según doc)
LEFT JOIN IMAGADM.IDTP_IMAGENES img_mayor
    ON img_mayor.NU_DNI = a.NU_DNI
LEFT JOIN IMAGADM.IDTP_IMAGEN_MENOR img_menor
    ON img_menor.NU_DNI = a.NU_DNI

WHERE
    a.NU_DNI = :p_numero_dni;

-- =============================================================================
-- NOTAS DE AJUSTE
-- =============================================================================
-- 1) GETM_ANI no tiene CO_UBIGEO_*. Nacimiento se arma con:
--    CO_DEPARTAMENTO_NACI, CO_PROVINCIA_NACI, CO_DISTRITO_NACI -> CO_UBIGEO 6 dígitos.
--    Extranjeros: CO_CONTINENTE_NACI, CO_PAIS_NACI (catálogos CONTINENTE, PAIS en GETR_DOMINIOS o tablas propias).
--    Cuarto nivel: CO_CENTRO_POBLADO_NACI (dominio CENTRO_POBLADO o tabla de centros poblados).
--    Domicilio: no hay campo UBIGEO; confirmar CO_*_DOM o columnas de dirección (DE_DIRECCION, etc.).
-- 2) GEVW_UBIGEO: CO_UBIGEO 6 dígitos (sin guión); DE_UBIGEO_CAPTU (reemplazar '/' por ' / ', TRIM).
-- 3) GETM_RESTRICCION: DE_CEL con DECODES; si existe registro -> deEstadoDNI no VIGENTE.
-- 4) IDTP_IMAGENES: Clave por TIPO y NRO FICHA IMAGEN o NU_FORMULARIO; IM_HUELLA si existe.
-- 5) Cuarto nivel: cp_nac desde GETR_DOMINIOS (CENTRO_POBLADO) o tabla GETR_CENTRO_POBLADO; ajustar según modelo.
-- 6) RRCC: Si nuTarjeta/dni viene de RRCC, JOIN a IDORRCC.RCTM_NACIMIENTOS por NU_CUI.
-- =============================================================================

-- =============================================================================
-- VERSIÓN SIMPLIFICADA (solo GETM_ANI + dominios básicos; sin ubigeo ni domicilio compuesto)
-- Útil cuando las columnas de ubigeo/domicilio o tablas auxiliares no existan aún.
-- =============================================================================
/*
SELECT
    LPAD(TRIM(TO_CHAR(a.NU_DNI)), 8, '0')     AS nuTarjeta,
    TO_CHAR(a.FE_EMISION, 'YYYYMMDD')         AS feEmision,
    CASE WHEN EXTRACT(YEAR FROM a.FE_CADUCIDAD) = 3000 THEN NULL
         ELSE TO_CHAR(a.FE_CADUCIDAD, 'YYYYMMDD') END AS feVencimiento,
    '3'                                       AS versionDNI,
    CASE WHEN res.NU_DNI IS NOT NULL THEN NVL(TRIM(res.DE_CEL), 'VIGENTE') ELSE 'VIGENTE' END AS deEstadoDNI,
    LPAD(TRIM(TO_CHAR(a.NU_DNI)), 8, '0')     AS dni,
    TRIM(a.PRENOM_INSCRITO)                   AS prenombres,
    TRIM(a.AP_PRIMER)                         AS primerApellido,
    TRIM(a.AP_SEGUNDO)                        AS segundoApellido,
    TO_CHAR(a.FE_NACIMIENTO, 'YYYYMMDD')      AS feNacimiento,
    NULL                                      AS deLugarNacimiento,
    TRIM(a.DE_GENERO)                          AS sexo,
    COALESCE(ec.DE_ESTADO_CIVIL, a.DE_ESTADO_CIVIL) AS estadoCivil,
    NULL                                      AS foto,
    NULL                                      AS huellaDigital,
    TRIM(NVL(a.DE_PREF_DIRECCION, '') || ' ' || NVL(a.DE_DIRECCION, '') || ' ' || NVL(TO_CHAR(a.NU_DIRECCION), '')) AS domicilio,
    'PERUANO'                                 AS nacionalidad,
    'Si'                                      AS donacionOrganos,
    NULL                                      AS cuartoNivel
FROM IDOTABMAESTRA.GETM_ANI a
LEFT JOIN IDOTABMAESTRA.GETR_ESTADO_CIVIL ec   ON ec.CO_ESTADO_CIVIL = a.CO_ESTADO_CIVIL
LEFT JOIN IDOTABMAESTRA.GETM_RESTRICCION res   ON res.NU_DNI = a.NU_DNI
WHERE a.NU_DNI = :p_numero_dni;
*/
