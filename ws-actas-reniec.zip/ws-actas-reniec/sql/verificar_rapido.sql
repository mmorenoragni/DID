-- Verificación rápida del estado de la base de datos
-- Ejecutar: docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 @sql/verificar_rapido.sql

SET PAGESIZE 1000
SET LINESIZE 200
SET SERVEROUTPUT ON

PROMPT ==========================================
PROMPT VERIFICACIÓN RÁPIDA DE LA BASE DE DATOS
PROMPT ==========================================
PROMPT

-- Verificar usuario IDORRCC
PROMPT 1. Verificando usuario IDORRCC...
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓ EXISTE' ELSE '✗ NO EXISTE' END AS ESTADO,
    USERNAME
FROM ALL_USERS 
WHERE USERNAME = 'IDORRCC'
GROUP BY USERNAME;

-- Verificar tablas
PROMPT
PROMPT 2. Verificando tablas del esquema IDORRCC...
SELECT 
    CASE WHEN COUNT(*) >= 5 THEN '✓ TODAS LAS TABLAS EXISTEN (' || COUNT(*) || ')' 
         WHEN COUNT(*) > 0 THEN '⚠ ALGUNAS TABLAS FALTAN (' || COUNT(*) || ' encontradas)'
         ELSE '✗ NO HAY TABLAS' END AS ESTADO
FROM ALL_TABLES 
WHERE OWNER = 'IDORRCC';

SELECT TABLE_NAME 
FROM ALL_TABLES 
WHERE OWNER = 'IDORRCC'
ORDER BY TABLE_NAME;

-- Verificar procedimiento
PROMPT
PROMPT 3. Verificando procedimiento SP_ACTA_NACIMIENTO...
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓ EXISTE' ELSE '✗ NO EXISTE' END AS ESTADO,
    OBJECT_NAME,
    OBJECT_TYPE
FROM ALL_OBJECTS 
WHERE OWNER = 'IDORRCC' 
AND OBJECT_NAME = 'SP_ACTA_NACIMIENTO'
AND OBJECT_TYPE = 'PROCEDURE'
GROUP BY OBJECT_NAME, OBJECT_TYPE;

-- Verificar datos de ejemplo
PROMPT
PROMPT 4. Verificando datos de ejemplo...
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓ HAY DATOS (' || COUNT(*) || ' actas)' 
         ELSE '✗ NO HAY DATOS' END AS ESTADO
FROM IDORRCC.RCTM_NACIMIENTOS;

PROMPT
PROMPT ==========================================
PROMPT Si ves ✗ en algún punto, ejecuta:
PROMPT docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_all_in_one.sql
PROMPT ==========================================

EXIT;
