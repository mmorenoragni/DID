-- =============================================================================
-- Datos mock para pruebas de V_DATOS_IDENTIDAD_DIGITAL y SP_CONSULTA_DATOS_DNI
-- Esquema IDORRCC (Docker). Ejecutar después de 02_create_tables_from_csv.sql
-- =============================================================================

ALTER SESSION SET CURRENT_SCHEMA = IDORRCC;

-- ============================================
-- 1. GETR_ESTADO_CIVIL
-- ============================================
INSERT INTO IDORRCC.GETR_ESTADO_CIVIL (co_estado_civil, de_estado_civil) VALUES ('01', 'SOLTERO');
INSERT INTO IDORRCC.GETR_ESTADO_CIVIL (co_estado_civil, de_estado_civil) VALUES ('02', 'CASADO');
INSERT INTO IDORRCC.GETR_ESTADO_CIVIL (co_estado_civil, de_estado_civil) VALUES ('03', 'VIUDO');
INSERT INTO IDORRCC.GETR_ESTADO_CIVIL (co_estado_civil, de_estado_civil) VALUES ('04', 'DIVORCIADO');
INSERT INTO IDORRCC.GETR_ESTADO_CIVIL (co_estado_civil, de_estado_civil) VALUES ('05', 'CONVIVIENTE');

-- ============================================
-- 2. GETR_GRUPO_FACTOR_SANGUINEO
-- ============================================
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (1, 'O+', '1');
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (2, 'O-', '1');
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (3, 'A+', '1');
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (4, 'A-', '1');
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (5, 'B+', '1');
INSERT INTO IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (co_grupo_factor, de_grupo_factor, es_grupo_factor) VALUES (6, 'AB+', '1');

-- ============================================
-- 3. GETR_OBSERVACION
-- ============================================
INSERT INTO IDORRCC.GETR_OBSERVACION (co_obs, de_obs, es_observacion) VALUES ('01', 'HUELLAS MALTRATADAS', '1');
INSERT INTO IDORRCC.GETR_OBSERVACION (co_obs, de_obs, es_observacion) VALUES ('02', 'FOTO CON LENTES', '1');
INSERT INTO IDORRCC.GETR_OBSERVACION (co_obs, de_obs, es_observacion) VALUES ('03', 'OBSERVACIÓN REGISTRAL', '1');

-- ============================================
-- 4. GETR_DOMINIOS (TIPO_SEXO, DE_PREF_* para domicilio)
-- ============================================
-- Sexo (vista: NO_DOM='TIPO_SEXO', CO_DOMINIO=A.DE_GENERO)
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('01', 'TIPO_SEXO', 'MASCULINO', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('02', 'TIPO_SEXO', 'FEMENINO', '1');
-- Prefijos dirección (vista: NO_DOM='DE_PREF_DIRECCION', CO_DOMINIO=A.DE_PREF_DIRECCION)
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('AV', 'DE_PREF_DIRECCION', 'AVENIDA', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('JR', 'DE_PREF_DIRECCION', 'JIRÓN', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('CL', 'DE_PREF_DIRECCION', 'CALLE', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('PS', 'DE_PREF_DIRECCION', 'PASAJE', '1');
-- Prefijos block
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('B', 'DE_PREF_BLOCK', 'BLOCK', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('DP', 'DE_PREF_BLOCK', 'DEPARTAMENTO', '1');
-- Prefijos interior
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('IN', 'DE_PREF_INTERIOR', 'INTERIOR', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('OF', 'DE_PREF_INTERIOR', 'OFICINA', '1');
-- Prefijos urb
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('URB', 'DE_PREF_URB', 'URBANIZACIÓN', '1');
INSERT INTO IDORRCC.GETR_DOMINIOS (co_dominio, no_dom, de_dom, es_dom) VALUES ('AAHH', 'DE_PREF_URB', 'ASENTAMIENTO HUMANO', '1');

-- ============================================
-- 5. GEVW_UBIGEOS (Lima 150101, Lima 150115 - San Isidro)
-- ============================================
INSERT INTO IDORRCC.GEVW_UBIGEOS (
    co_ubigeo, co_departamento, co_provincia, co_distrito, co_pais, co_continente, co_centro_poblado_o,
    de_ubigeo, de_ubigeo_captu, no_departamento, no_provincia, no_distrito, no_pais, es_ubigeo
) VALUES (
    '150101', '15', '01', '01', 'PE', 'AM', ' ',
    'LIMA / LIMA / LIMA', 'LIMA / LIMA / LIMA', 'LIMA', 'LIMA', 'LIMA', 'PERÚ', '1'
);
INSERT INTO IDORRCC.GEVW_UBIGEOS (
    co_ubigeo, co_departamento, co_provincia, co_distrito, co_pais, co_continente, co_centro_poblado_o,
    de_ubigeo, de_ubigeo_captu, no_departamento, no_provincia, no_distrito, no_pais, es_ubigeo
) VALUES (
    '150115', '15', '01', '15', 'PE', 'AM', ' ',
    'LIMA / LIMA / SAN ISIDRO', 'LIMA / LIMA / SAN ISIDRO', 'LIMA', 'LIMA', 'SAN ISIDRO', 'PERÚ', '1'
);
INSERT INTO IDORRCC.GEVW_UBIGEOS (
    co_ubigeo, co_departamento, co_provincia, co_distrito, co_pais, co_continente, co_centro_poblado_o,
    de_ubigeo, de_ubigeo_captu, no_departamento, no_provincia, no_distrito, no_pais, es_ubigeo
) VALUES (
    '150132', '15', '01', '32', 'PE', 'AM', ' ',
    'LIMA / LIMA / SAN JUAN DE MIRAFLORES', 'LIMA / LIMA / SAN JUAN DE MIRAFLORES', 'LIMA', 'LIMA', 'SAN JUAN DE MIRAFLORES', 'PERÚ', '1'
);

-- ============================================
-- 6. GETM_RESTRICCION
-- ============================================
INSERT INTO IDORRCC.GETM_RESTRICCION (co_restri, de_restri, de_cel, es_restri) VALUES ('00', 'SIN RESTRICCIÓN', 'SIN RESTRICCIÓN', '1');
INSERT INTO IDORRCC.GETM_RESTRICCION (co_restri, de_restri, de_cel, es_restri) VALUES ('01', 'FALLECIDO', 'RESTRICCIÓN - FALLECIDO', '1');
INSERT INTO IDORRCC.GETM_RESTRICCION (co_restri, de_restri, de_cel, es_restri) VALUES ('02', 'SUSTITUIDO', 'RESTRICCIÓN - SUSTITUIDO', '1');

-- ============================================
-- 7. GETM_ANI (2 titulares de prueba)
-- ============================================
-- DNI 45678901: persona con domicilio decodificado, sin observaciones, sin restricción
INSERT INTO IDORRCC.GETM_ANI (
    nu_dni, ap_primer, ap_segundo, prenom_inscrito, fe_nacimiento,
    co_departamento_naci, co_provincia_naci, co_distrito_naci, co_pais_naci, co_continente_naci, co_centro_poblado_naci,
    co_departamento_domicilio, co_provincia_domicilio, co_distrito_domicilio, co_pais_domicilio, co_continente_domicilio, co_centro_poblado_domicilio,
    co_estado_civil, co_grupo_sanguineo, co_restri, de_genero,
    de_pref_direccion, de_direccion, nu_direccion, de_pref_block, de_block_chalet, de_urbanizacion, de_manzana, de_lote_direccion,
    fe_emision, fe_caducidad, co_tipo_doc_padre, nu_doc_padre, co_tipo_doc_madre, nu_doc_madre,
    nu_ficha_reg, ti_ficha_reg, ti_ficha_imag
) VALUES (
    '45678901', 'PEREZ', 'GARCIA', 'MARIA ELENA', TO_DATE('1995-03-20', 'YYYY-MM-DD'),
    '15', '01', '15', 'PE', 'AM', ' ',
    '15', '01', '15', 'PE', 'AM', ' ',
    '02', 3, '00', '02',
    'AV', 'CONQUISTADORES', '1234', 'DP', '501', 'LOS PINOS', 'A', '15',
    TO_DATE('2024-01-10', 'YYYY-MM-DD'), TO_DATE('2034-01-10', 'YYYY-MM-DD'), '01', '12345678', '01', '87654321',
    'F-2024-001', '01', '01'
);

-- DNI 12345678: con observación, posible restricción nula, apellido casada
INSERT INTO IDORRCC.GETM_ANI (
    nu_dni, ap_primer, ap_segundo, ap_casada, prenom_inscrito, fe_nacimiento,
    co_departamento_naci, co_provincia_naci, co_distrito_naci, co_pais_naci, co_continente_naci, co_centro_poblado_naci,
    co_departamento_domicilio, co_provincia_domicilio, co_distrito_domicilio, co_pais_domicilio, co_continente_domicilio, co_centro_poblado_domicilio,
    co_estado_civil, co_grupo_sanguineo, co_restri, de_genero,
    de_pref_direccion, de_direccion, nu_direccion, de_urbanizacion, de_etapa, de_manzana, de_lote_direccion,
    fe_emision, fe_caducidad, co_tipo_doc_padre, nu_doc_padre, ap_padre_primer, ap_padre_segundo, prenom_padre,
    co_tipo_doc_madre, nu_doc_madre, ap_madre_primer, ap_madre_segundo, prenom_madre,
    nu_ficha_reg, ti_ficha_reg, ti_ficha_imag
) VALUES (
    '12345678', 'LOPEZ', 'SILVA', 'DE LA CRUZ', 'JUAN CARLOS', TO_DATE('1988-07-15', 'YYYY-MM-DD'),
    '15', '01', '01', 'PE', 'AM', ' ',
    '15', '01', '32', 'PE', 'AM', ' ',
    '02', 1, '00', '01',
    'JR', 'LOS HEROES', '456', 'VILLA SOL', '2', 'B', '8',
    TO_DATE('2023-06-01', 'YYYY-MM-DD'), TO_DATE('3000-12-31', 'YYYY-MM-DD'),
    '01', '44556677', 'LOPEZ', 'VEGA', 'PEDRO',
    '01', '99887766', 'SILVA', 'MENDIETA', 'ROSA',
    'F-2023-002', '01', '01'
);

-- ============================================
-- 8. GETM_OBSERVACION_DNI (solo 12345678 tiene observación)
-- ============================================
INSERT INTO IDORRCC.GETM_OBSERVACION_DNI (nu_dni, co_obs, es_observacion) VALUES ('12345678', '01', '1');

-- ============================================
-- 9. IDTP_IMAGENES (opcional: ficha para ambos DNI; foto BLOB NULL para prueba)
-- ============================================
INSERT INTO IDORRCC.IDTP_IMAGENES (nu_formulario, ti_doc_reg_ficha) VALUES ('F-2024-001', '01');
INSERT INTO IDORRCC.IDTP_IMAGENES (nu_formulario, ti_doc_reg_ficha) VALUES ('F-2023-002', '01');

COMMIT;

PROMPT Datos mock insertados. Probar con:
PROMPT   SELECT * FROM IDORRCC.V_DATOS_IDENTIDAD_DIGITAL WHERE CUI_DNI IN ('12345678','45678901');
PROMPT   EXEC IDORRCC.SP_CONSULTA_DATOS_DNI('12345678', :c);
EXIT;
