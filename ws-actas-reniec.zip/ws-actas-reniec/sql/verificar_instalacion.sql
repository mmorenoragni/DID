-- Script para verificar si el esquema y procedimiento existen
-- Ejecutar como: sqlplus system/oracle@FREEPDB1 @verificar_instalacion.sql

SET SERVEROUTPUT ON;

-- Verificar si el usuario IDORRCC existe
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM ALL_USERS
    WHERE USERNAME = 'IDORRCC';
    
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('✓ Usuario IDORRCC existe');
    ELSE
        DBMS_OUTPUT.PUT_LINE('✗ Usuario IDORRCC NO existe');
    END IF;
END;
/

-- Verificar si las tablas existen
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓' ELSE '✗' END || ' Tablas encontradas: ' || COUNT(*) AS ESTADO
FROM ALL_TABLES 
WHERE OWNER = 'IDORRCC';

-- Listar tablas del esquema IDORRCC
SELECT TABLE_NAME 
FROM ALL_TABLES 
WHERE OWNER = 'IDORRCC'
ORDER BY TABLE_NAME;

-- Verificar si el procedimiento existe
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓' ELSE '✗' END || ' Procedimiento SP_ACTA_NACIMIENTO: ' || 
    CASE WHEN COUNT(*) > 0 THEN 'EXISTE' ELSE 'NO EXISTE' END AS ESTADO
FROM ALL_PROCEDURES 
WHERE OWNER = 'IDORRCC' 
AND OBJECT_NAME = 'SP_ACTA_NACIMIENTO';

-- Verificar permisos
SELECT 
    CASE WHEN COUNT(*) > 0 THEN '✓' ELSE '✗' END || ' Permisos de ejecución: ' ||
    CASE WHEN COUNT(*) > 0 THEN 'OTORGADOS' ELSE 'NO OTORGADOS' END AS ESTADO
FROM ALL_TAB_PRIVS 
WHERE GRANTEE = 'SYSTEM' 
AND OWNER = 'IDORRCC';

EXIT;
