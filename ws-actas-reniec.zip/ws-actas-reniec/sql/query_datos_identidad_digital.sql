-- =============================================================================
-- CONSULTA Y STORED PROCEDURE: DATOS DE LA IDENTIDAD DIGITAL (DNI)
-- Según: 16ENE2026 - Estructura Datos CREDENCIALES 1(DNI).csv
-- Esquema: IDORRCC (GETM_ANI, GEVW_UBIGEOS, GETR_*, IDTP_IMAGENES, IDTP_IMAGEN_MENOR)
-- =============================================================================

ALTER SESSION SET CURRENT_SCHEMA = IDORRCC;

-- =============================================================================
-- 1. VISTA: Datos para visualizar como "Datos de la Identidad Digital"
--    (Una fila por DNI con todos los campos del mockup)
-- =============================================================================

CREATE OR REPLACE VIEW IDORRCC.V_DATOS_IDENTIDAD_DIGITAL AS
SELECT
    -- (01) Código Único de Identificación - Número DNI
    A.NU_DNI AS CUI_DNI,
    -- (02) Nombres
    A.PRENOM_INSCRITO AS PRENOMBRES,
    -- (03) Apellido paterno
    A.AP_PRIMER AS APELLIDO_PATERNO,
    -- (04) Apellido materno
    A.AP_SEGUNDO AS APELLIDO_MATERNO,
    -- (05) Apellido de casada
    A.AP_CASADA AS APELLIDO_CASADA,
    -- (06) Fecha de nacimiento
    A.FE_NACIMIENTO AS FECHA_NACIMIENTO,
    -- (07) Lugar de nacimiento (Ubigeo descriptivo)
    TRIM(REPLACE(NVL(U_NACI.DE_UBIGEO_CAPTU, U_NACI.DE_UBIGEO), '/', ' / ')) AS LUGAR_NACIMIENTO,
    -- (08) UBIGEO de nacimiento (código, sin guión)
    REPLACE(NVL(U_NACI.CO_UBIGEO, ''), '-', '') AS UBIGEO_NACIMIENTO,
    -- (09) Sexo (GETR_DOMINIOS DE_DOM o GETM_ANI.DE_GENERO)
    NVL(D_SEXO."DE_DOM", A.DE_GENERO) AS SEXO,
    -- (10) Estado civil
    E.DE_ESTADO_CIVIL AS ESTADO_CIVIL,
    -- (11) Foto: mayor -> IM_FOTO, menor -> IM_FOTO_MENOR
    NVL(IMG.IM_FOTO, IMGM.IM_FOTO_MENOR) AS FOTO,
    -- (12) UBIGEO domicilio (código)
    REPLACE(NVL(U_DOM.CO_UBIGEO, ''), '-', '') AS UBIGEO_DOMICILIO,
    -- (13) Lugar de domicilio (descriptivo)
    TRIM(REPLACE(NVL(U_DOM.DE_UBIGEO_CAPTU, U_DOM.DE_UBIGEO), '/', ' / ')) AS LUGAR_DOMICILIO,
    -- (14) Domicilio (decodificado con GETR_DOMINIOS)
    TRIM(REPLACE(REPLACE(REPLACE(
        DECODE(A.DE_PREF_DIRECCION, NULL, NULL,
            (SELECT D.DE_DOM FROM IDORRCC.GETR_DOMINIOS D
             WHERE D.NO_DOM = 'DE_PREF_DIRECCION' AND D.CO_DOMINIO = A.DE_PREF_DIRECCION AND D.ES_DOM = '1')) || ' ' ||
        A.DE_DIRECCION || ' ' || A.NU_DIRECCION || ' ' ||
        DECODE(A.DE_PREF_BLOCK, NULL, NULL,
            (SELECT D.DE_DOM FROM IDORRCC.GETR_DOMINIOS D
             WHERE D.NO_DOM = 'DE_PREF_BLOCK' AND D.CO_DOMINIO = A.DE_PREF_BLOCK AND D.ES_DOM = '1')) || ' ' ||
        A.DE_BLOCK_CHALET || ' ' ||
        DECODE(A.DE_PREF_INTERIOR, NULL, NULL,
            (SELECT D.DE_DOM FROM P.GETR_DOMINIOS D
             WHERE D.NO_DOM = 'DE_PREF_INTERIOR' AND D.CO_DOMINIO = A.DE_PREF_INTERIOR AND D.ES_DOM = '1')) || ' ' ||
        A.DE_INTERIOR || ' ' ||
        DECODE(A.DE_PREF_URB, NULL, NULL,
            (SELECT D.DE_DOM FROM IDORRCC.GETR_DOMINIOS D
             WHERE D.NO_DOM = 'DE_PREF_URB' AND D.CO_DOMINIO = A.DE_PREF_URB AND D.ES_DOM = '1')) || ' ' ||
        A.DE_URBANIZACION || ' ' ||
        DECODE(A.DE_ETAPA, NULL, NULL, 'ETAPA ' || A.DE_ETAPA) || ' ' ||
        DECODE(A.DE_MANZANA, NULL, NULL, 'MZ. ' || A.DE_MANZANA) || ' ' ||
        DECODE(A.DE_LOTE_DIRECCION, NULL, NULL, 'LT. ' || A.DE_LOTE_DIRECCION),
        '   ', ' '), '  ', ' '), '  ', ' ')) AS DOMICILIO,
    -- (15) Grupo y factor sanguíneo
    G.DE_GRUPO_FACTOR AS GRUPO_FACTOR_SANGUINEO,
    -- (16) Observaciones (Oracle 10g: SYS_CONNECT_BY_PATH)
    OBS.LISTA_OBSERVACIONES AS OBSERVACIONES,
    -- (17) Restricción (DE_CEL con formato; si no hay -> 'SIN RESTRICCIÓN')
    NVL(TRIM(NVL(DECODE(R.DE_CEL, NULL, NULL,
        DECODE(INSTR(R.DE_CEL, '-'), 0, R.DE_CEL, SUBSTR(R.DE_CEL, INSTR(R.DE_CEL, '-') + 2))), ' ')), 'SIN RESTRICCIÓN') AS RESTRICCION,
    -- (18) Fecha de emisión DNIe
    A.FE_EMISION AS FECHA_EMISION_DNIE,
    -- (19) Fecha de caducidad DNIe (año 3000 -> 'NO CADUCA')
    CASE WHEN A.FE_CADUCIDAD IS NOT NULL AND TO_NUMBER(TO_CHAR(A.FE_CADUCIDAD, 'YYYY')) = 3000
         THEN 'NO CADUCA'
         ELSE TO_CHAR(A.FE_CADUCIDAD, 'DD/MM/YYYY')
    END AS FECHA_CADUCIDAD_DNIE,
    -- (20-23) Progenitores
    A.CO_TIPO_DOC_PADRE AS TIPO_DOC_PROGENITOR1,
    A.NU_DOC_PADRE AS NUM_DOC_PROGENITOR1,
    A.CO_TIPO_DOC_MADRE AS TIPO_DOC_PROGENITOR2,
    A.NU_DOC_MADRE AS NUM_DOC_PROGENITOR2,
    -- (25) Nacionalidad
    'PER' AS NACIONALIDAD
FROM
    IDORRCC.GETM_ANI A
    LEFT JOIN IDORRCC.GEVW_UBIGEOS U_NACI
        ON U_NACI.CO_DEPARTAMENTO = A.CO_DEPARTAMENTO_NACI
       AND U_NACI.CO_PROVINCIA    = A.CO_PROVINCIA_NACI
       AND U_NACI.CO_DISTRITO     = A.CO_DISTRITO_NACI
       AND U_NACI.CO_PAIS = A.CO_PAIS_NACI
       AND U_NACI.CO_CONTINENTE = A.CO_CONTINENTE_NACI
       AND U_NACI.CO_CENTRO_POBLADO_O = A.CO_CENTRO_POBLADO_NACI
    LEFT JOIN IDORRCC.GEVW_UBIGEOS U_DOM
        ON U_DOM.CO_DEPARTAMENTO = A.CO_DEPARTAMENTO_DOMICILIO
       AND U_DOM.CO_PROVINCIA    = A.CO_PROVINCIA_DOMICILIO
       AND U_DOM.CO_DISTRITO      = A.CO_DISTRITO_DOMICILIO
       AND U_DOM.CO_PAIS = A.CO_PAIS_DOMICILIO
       AND U_DOM.CO_CONTINENTE = A.CO_CONTINENTE_DOMICILIO
       AND U_DOM.CO_CENTRO_POBLADO_O = A.CO_CENTRO_POBLADO_DOMICILIO
    LEFT JOIN IDORRCC.GETR_ESTADO_CIVIL E
        ON E.CO_ESTADO_CIVIL = A.CO_ESTADO_CIVIL
    LEFT JOIN IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO G
        ON G.CO_GRUPO_FACTOR = A.CO_GRUPO_SANGUINEO
    LEFT JOIN IDORRCC.GETM_RESTRICCION R
        ON R.CO_RESTRI = A.CO_RESTRI
    LEFT JOIN IDORRCC.GETR_DOMINIOS D_SEXO
        ON D_SEXO.NO_DOM = 'TIPO_SEXO' AND D_SEXO.CO_DOMINIO = A.DE_GENERO
    LEFT JOIN (
        SELECT NU_DNI,
               LTRIM(MAX(SYS_CONNECT_BY_PATH(DE_OBS, '; ')), '; ') AS LISTA_OBSERVACIONES
        FROM (
            SELECT OD.NU_DNI, R_OBS.DE_OBS,
                   ROW_NUMBER() OVER (PARTITION BY OD.NU_DNI ORDER BY OD.CO_OBS) AS rn
            FROM IDORRCC.GETM_OBSERVACION_DNI OD
            JOIN IDORRCC.GETR_OBSERVACION R_OBS ON R_OBS.CO_OBS = OD.CO_OBS
        ) t
        START WITH rn = 1
        CONNECT BY PRIOR rn = rn - 1 AND PRIOR NU_DNI = NU_DNI
        GROUP BY NU_DNI
    ) OBS ON OBS.NU_DNI = A.NU_DNI
    LEFT JOIN IDORRCC.IDTP_IMAGENES IMG
        ON IMG.NU_FORMULARIO = A.NU_FICHA_REG AND IMG.TI_DOC_REG_FICHA = NVL(A.TI_FICHA_REG, A.TI_FICHA_IMAG)
    LEFT JOIN IDORRCC.IDTP_IMAGEN_MENOR IMGM
        ON IMGM.NU_FORMULARIO = A.NU_FICHA_REG AND IMGM.TI_DOC_REG_FICHA = NVL(A.TI_FICHA_REG, A.TI_FICHA_IMAG)
;

-- =============================================================================
-- 2. STORED PROCEDURE: Consulta por DNI (retorna un cursor con una fila)
--    Uso: EXEC SP_CONSULTA_DATOS_DNI('12345678', :cursor);
-- =============================================================================

CREATE OR REPLACE PROCEDURE SP_CONSULTA_DATOS_DNI (
    p_nu_dni    IN  VARCHAR2,
    p_resultado OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_resultado FOR
        SELECT *
        FROM V_DATOS_IDENTIDAD_DIGITAL
        WHERE CUI_DNI = p_nu_dni;
END SP_CONSULTA_DATOS_DNI;
/

-- =============================================================================
-- 3. EJEMPLO DE CONSULTA DIRECTA (sin procedure)
-- =============================================================================
-- Sustituir :dni por el número a consultar.
/*
SELECT * FROM IDORRCC.V_DATOS_IDENTIDAD_DIGITAL WHERE CUI_DNI = '12345678';
*/

-- =============================================================================
-- 4. EJEMPLO DE LLAMADA AL PROCEDIMIENTO DESDE SQL*Plus / SQL Developer
-- =============================================================================
/*
VAR c REFCURSOR;
EXEC IDORRCC.SP_CONSULTA_DATOS_DNI('12345678', :c);
PRINT c;
*/

COMMIT;
PROMPT Vista V_DATOS_IDENTIDAD_DIGITAL y procedimiento SP_CONSULTA_DATOS_DNI creados.
EXIT;
