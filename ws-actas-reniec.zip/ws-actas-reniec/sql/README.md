# Scripts SQL para Base de Datos Oracle

Este directorio contiene los scripts SQL necesarios para crear las tablas y el procedimiento almacenado `SP_ACTA_NACIMIENTO`.

## Estructura de Archivos

- **00_drop_all_tables.sql**: Elimina todas las tablas y procedimientos del esquema IDORRCC (limpieza).
- **00_all_in_one.sql**: Script completo que ejecuta todo de una vez (esquema antiguo RCTM/RCTR).
- **01_create_schema.sql**: Crea el esquema y usuario IDORRCC.
- **02_create_tables_from_csv.sql**: Crea las 10 tablas según definiciones CSV (GETM_ANI, GEVW_UBIGEOS, GETR_*, IDTP_*).
- **02_create_catalog_tables.sql**: Crea las tablas catálogo antiguas (maestros).
- **03_create_main_tables.sql**: Crea las tablas principales antiguas.
- **04_create_procedure.sql**: Crea el procedimiento almacenado SP_ACTA_NACIMIENTO.
- **05_insert_sample_data.sql**: Inserta datos de ejemplo para pruebas.
- **ejecutar_limpieza_y_recrear.sh**: Limpia tablas y recrea con las 10 tablas nuevas (recomendado para esquema CSV).
- **query_datos_identidad_digital.sql**: Vista **V_DATOS_IDENTIDAD_DIGITAL** y procedimiento **SP_CONSULTA_DATOS_DNI** para consulta de datos del DNI digital según especificación (Estructura Datos CREDENCIALES 1).

## Tablas (esquema nuevo desde CSV – 02_create_tables_from_csv.sql)

Tras ejecutar **ejecutar_limpieza_y_recrear.sh** (o 00_drop_all_tables + 02_create_tables_from_csv) quedan estas tablas:

### Catálogos (GETR_*)
1. **GETR_ESTADO_CIVIL**: Estado civil.
2. **GETR_GRUPO_FACTOR_SANGUINEO**: Grupo y factor sanguíneo.
3. **GETR_OBSERVACION**: Observaciones (códigos y descripciones).
4. **GETR_DOMINIOS**: Dominios genéricos.

### Maestros / Vistas (GETM_*, GEVW_*)
5. **GEVW_UBIGEOS**: Ubigeos (ubicación geográfica).
6. **GETM_RESTRICCION**: Restricciones.
7. **GETM_ANI**: Maestro DNI / acta nacimiento inscripción (datos del titular).
8. **GETM_OBSERVACION_DNI**: Relación DNI – observaciones.

### Imágenes (IDTP_*)
9. **IDTP_IMAGENES**: Imágenes DNI (foto, firma, huellas, template).
10. **IDTP_IMAGEN_MENOR**: Imágenes DNI menor (foto menor, firma declarante, huellas).

---

## Tablas del esquema antiguo (00_all_in_one / 02 + 03)

### Tablas Catálogo (Maestros)
1. **RCTR_TIPO_VINCULO_FAMILIAR**: Tipos de vínculo familiar (PADRE, MADRE, TUTOR, etc.)
2. **RCTR_TIPO_DOC_IDENTIDAD**: Tipos de documento de identidad (DNI, PASAPORTE, etc.)

### Tablas Principales
1. **RCTM_NACIMIENTOS**: Información de actas de nacimiento
2. **RCTM_NACIMIENTOS_ACTORES**: Información de progenitores/actores del nacimiento
3. **RCTM_ESCANEO**: Imágenes escaneadas de las actas

## Ejecución Automática con Docker Compose

Los scripts en el directorio `./sql` se ejecutan automáticamente al iniciar el contenedor Oracle, ya que están montados en `/container-entrypoint-initdb.d`.

**Orden de ejecución**: Los archivos se ejecutan en orden alfabético, por eso están numerados (00, 01, 02, etc.)

## Ejecución Manual

**Limpieza y recreación con las 10 tablas desde CSV (recomendado):**

```bash
./sql/ejecutar_limpieza_y_recrear.sh
```

O paso a paso:

```bash
# 1. Limpiar todas las tablas del esquema IDORRCC
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_drop_all_tables.sql

# 2. Crear las 10 tablas (GETR_*, GETM_*, GEVW_*, IDTP_*)
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/02_create_tables_from_csv.sql
```

**Esquema antiguo (RCTM/RCTR + SP_ACTA_NACIMIENTO):**

```bash
# Conectar a la base de datos
docker exec -it oracle-free sqlplus system/oracle@FREEPDB1

# O ejecutar un script específico
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_all_in_one.sql
```

## Estructura de Datos

### RCTM_NACIMIENTOS
- `NU_ACTA_NACIMIENTO` (PK): Número de acta de nacimiento
- `NU_CUI`: Código Único de Identificación
- `DE_PRE_NOMBRES`: Nombres
- `DE_PRIMER_APELLIDO`: Primer apellido
- `DE_SEGUNDO_APELLIDO`: Segundo apellido
- `FE_NACIMIENTO`: Fecha de nacimiento
- `CO_ESTADO_ACTA_NACIMIENTO`: Estado del acta ('1' = activo)
- `IM_NACIMIENTOS`: Imagen del anverso (BLOB)
- `IM_NACIMIENTOS_REV`: Imagen del reverso (BLOB)

### RCTM_NACIMIENTOS_ACTORES
- `NU_ACTA_NACIMIENTO` (FK): Referencia al acta de nacimiento
- `CO_TIPO_ACTOR_NACIMIENTO`: '01' = Progenitor 1, '02' = Progenitor 2
- `CO_VINCULO_FAMILIAR` (FK): Tipo de vínculo familiar
- `CO_TIPO_DOC_IDENTIDAD` (FK): Tipo de documento
- `NU_DOC_IDENTIDAD`: Número de documento

### RCTM_ESCANEO
- `NU_ACTA`: Número de acta
- `CO_TIPO_ACTA`: '01' = Nacimiento
- `CO_LADO_ACTA`: 'A' = Anverso, 'B' = Reverso
- `IM_ACTA`: Imagen escaneada (BLOB)

## Probar el Procedimiento Almacenado

```sql
DECLARE
    v_cursor SYS_REFCURSOR;
    v_cui VARCHAR2(20);
    v_nombres VARCHAR2(200);
    v_apellido1 VARCHAR2(100);
    v_apellido2 VARCHAR2(100);
    v_fecha DATE;
    v_vinculo1 VARCHAR2(100);
    v_tipo_doc1 VARCHAR2(100);
    v_num_doc1 VARCHAR2(20);
    v_vinculo2 VARCHAR2(100);
    v_tipo_doc2 VARCHAR2(100);
    v_num_doc2 VARCHAR2(20);
BEGIN
    SP_ACTA_NACIMIENTO(1001, v_cursor);
    LOOP
        FETCH v_cursor INTO v_cui, v_nombres, v_apellido1, v_apellido2, v_fecha,
                            v_vinculo1, v_tipo_doc1, v_num_doc1,
                            v_vinculo2, v_tipo_doc2, v_num_doc2,
                            v_imagen_anverso, v_imagen_reverso;
        EXIT WHEN v_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('CUI: ' || v_cui || ' - Nombre: ' || v_nombres || ' ' || v_apellido1);
    END LOOP;
    CLOSE v_cursor;
END;
/
```

## Notas Importantes

- El usuario `IDORRCC` se crea con contraseña `oracle`
- Los scripts incluyen datos de ejemplo (acta 1001) para pruebas
- Las imágenes BLOB se dejan como NULL en los ejemplos
- Los índices están optimizados para las consultas del procedimiento almacenado
