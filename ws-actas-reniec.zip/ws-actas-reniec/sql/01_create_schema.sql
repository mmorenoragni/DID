-- Script de creación de esquema y tablas para el procedimiento SP_ACTA_NACIMIENTO
-- Oracle Database Free - Docker

-- Crear el esquema IDORRCC si no existe
CREATE USER IDORRCC IDENTIFIED BY oracle;
GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE TO IDORRCC;
ALTER USER IDORRCC QUOTA UNLIMITED ON USERS;

-- Conectar al esquema IDORRCC
ALTER SESSION SET CURRENT_SCHEMA = IDORRCC;
