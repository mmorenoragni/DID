-- =============================================================================
-- Query DNI Digital - Campos según Etiqueta en MOCKUP
-- Origen: credenciales-from-emma.xlsx (tablas y campos)
-- Esquema IDOTABMAESTRA: GETM_ANI, GETM_OBSERVACION_DNI, GETM_RESTRICCION,
-- GETR_DOMINIOS, GETR_ESTADO_CIVIL, GETR_GRUPO_FACTOR_SANGUINEO, GETR_OBSERVACION,
-- GEVW_UBIGEO (vista). Esquema IMAGADM: IDTP_IMAGENES (mayores), IDTP_IMAGEN_MENOR (menores).
-- =============================================================================
-- NOTA: Ajustar nombres de esquema (IDOTABMAESTRA) y tablas según el ambiente real.
--       Nacionalidad (25), Correo electrónico (26) y Celular (27) figuran como
--       PENDIENTE/no disponibles en el Excel; se dejan como placeholder.
-- =============================================================================

SELECT
    -- (01) Código Único de Identificación-CUI - Número DNI
    a.NU_DNI                    AS cui_numero_dni,

    -- (02) Nombres
    a.PRENOM_INSCRITO           AS nombres,

    -- (03) Apellido paterno
    a.AP_PRIMER                 AS apellido_paterno,

    -- (04) Apellido materno
    a.AP_SEGUNDO                AS apellido_materno,

    -- (05) Apellido de casada
    a.AP_CASADA                 AS apellido_casada,

    -- (06) Fecha de nacimiento
    a.FE_NACIMIENTO             AS fecha_nacimiento,

    -- (07) Lugar de nacimiento (Ubigeo descriptivo + cuarto nivel)
    -- Origen: GEVW_UBIGEO; GETM_ANI no tiene columnas CO_*_NACIMIENTO para JOIN → NULL hasta definir columnas
    CAST(NULL AS VARCHAR2(400)) AS lugar_nacimiento,

    -- (08) UBIGEO de nacimiento (código)
    -- Ajustar a a.CO_UBIGEO_NACIMIENTO si existe en GETM_ANI
    CAST(NULL AS VARCHAR2(20))   AS ubigeo_nacimiento,

    -- (09) Sexo - Género registral
    -- Origen: GETM_ANI + GETR_DOMINIOS (dominio TIPO_SEXO) -> DE_DOM
    COALESCE(dom_sexo.DE_DOM, a.DE_GENERO) AS sexo,

    -- (10) Estado civil
    -- Origen: GETM_ANI + GETR_ESTADO_CIVIL
    COALESCE(ec.DE_ESTADO_CIVIL, a.DE_ESTADO_CIVIL) AS estado_civil,

    -- (11) Fotografía (Base64/tramada)
    -- Origen: IMAGADM.IDTP_IMAGENES (mayores) e IMAGADM.IDTP_IMAGEN_MENOR (menores)
    COALESCE(img_mayor.IM_FOTO, img_menor.IM_FOTO) AS foto,

    -- (12) UBIGEO de domicilio (código)
    -- Ajustar a a.CO_UBIGEO_DOMICILIO si existe en GETM_ANI
    CAST(NULL AS VARCHAR2(20))   AS ubigeo_domicilio,

    -- (13) Lugar de domicilio (UBIGEO descriptivo + cuarto nivel)
    -- GETM_ANI no tiene columnas CO_*_DOMICILIO para JOIN a GEVW_UBIGEO → NULL hasta definir
    CAST(NULL AS VARCHAR2(400)) AS lugar_domicilio,

    -- (14) Domicilio - Dirección domiciliaria
    -- Origen: DE_PREF_DIRECCION, DE_DIRECCION, NU_DIRECCION, etc. (GETR_DOMINIOS)
    a.DE_PREF_DIRECCION || ' ' || a.DE_DIRECCION || ' ' || NVL(a.NU_DIRECCION, '') AS domicilio,

    -- (15) Grupo y factor sanguíneo
    -- Origen: GETM_ANI (código) + GETR_GRUPO_FACTOR_SANGUINEO -> DE_GRUPO_FACTOR
    gfs.DE_GRUPO_FACTOR         AS grupo_factor_sanguineo,

    -- (16) Observaciones
    -- Origen: GETM_ANI + GETM_OBSERVACION_DNI + GETR_OBSERVACION -> DE_OBS
    obs.DE_OBS                  AS observaciones,

    -- (17) Restricción
    -- Origen: GETM_ANI + GETM_RESTRICCION
    res.DE_RESTRICCION          AS restriccion,

    -- 18 - Fecha de emisión DNIe
    a.FE_EMISION                AS fecha_emision_dnie,

    -- 19 - Fecha de caducidad DNIe (si año 3000 -> 'NO CADUCA')
    CASE WHEN EXTRACT(YEAR FROM a.FE_CADUCIDAD) = 3000 THEN 'NO CADUCA' ELSE TO_CHAR(a.FE_CADUCIDAD) END AS fecha_caducidad_dnie,

    -- (20) Tipo de documento del padre
    a.CO_TIPO_DOC_PADRE         AS tipo_documento_padre,

    -- (21) Número de documento del padre
    a.NU_DOC_PADRE              AS numero_documento_padre,

    -- (22) Tipo de documento de la madre
    a.CO_TIPO_DOC_MADRE         AS tipo_documento_madre,

    -- (23) Número de documento de la madre
    a.NU_DOC_MADRE              AS numero_documento_madre,

    -- 25 - Nacionalidad (Excel: no existe en RUIPN; placeholder)
    CAST(NULL AS VARCHAR2(10))  AS nacionalidad,

    -- 26 - Correo electrónico (Excel: PENDIENTE / opcional)
    CAST(NULL AS VARCHAR2(80))  AS correo_electronico,

    -- 27 - Celular (Excel: PENDIENTE; DE_CEL con DECODE según documentación)
    CAST(NULL AS VARCHAR2(9))   AS celular

FROM
    IDOTABMAESTRA.GETM_ANI a

-- Ubigeo: lugar (07, 13) y código (08, 12) en NULL hasta tener columnas en GETM_ANI.
-- Si GETM_ANI tiene CO_UBIGEO_NACIMIENTO / CO_UBIGEO_DOMICILIO, usarlos en SELECT y opcional:
-- LEFT JOIN IDOTABMAESTRA.GEVW_UBIGEO ubigeo_nac ON ubigeo_nac.CO_UBIGEO = a.CO_UBIGEO_NACIMIENTO
-- LEFT JOIN IDOTABMAESTRA.GEVW_UBIGEO ubigeo_dom ON ubigeo_dom.CO_UBIGEO = a.CO_UBIGEO_DOMICILIO

-- Sexo (dominio TIPO_SEXO) - si se usa GETR_DOMINIOS
LEFT JOIN IDOTABMAESTRA.GETR_DOMINIOS dom_sexo
    ON dom_sexo.CO_DOMINIO = 'TIPO_SEXO' AND dom_sexo.CO_DOM = a.CO_GENERO

-- Estado civil
LEFT JOIN IDOTABMAESTRA.GETR_ESTADO_CIVIL ec
    ON ec.CO_ESTADO_CIVIL = a.CO_ESTADO_CIVIL

-- Grupo y factor sanguíneo
LEFT JOIN IDOTABMAESTRA.GETR_GRUPO_FACTOR_SANGUINEO gfs
    ON gfs.CO_GRUPO_FACTOR = a.CO_GRUPO_FACTOR_SANGUINEO

-- Observaciones (GETM_OBSERVACION_DNI + GETR_OBSERVACION)
LEFT JOIN IDOTABMAESTRA.GETM_OBSERVACION_DNI obs_dni
    ON obs_dni.NU_DNI = a.NU_DNI  -- ajustar clave según modelo real
LEFT JOIN IDOTABMAESTRA.GETR_OBSERVACION obs
    ON obs.CO_OBSERVACION = obs_dni.CO_OBSERVACION

-- Restricción
LEFT JOIN IDOTABMAESTRA.GETM_RESTRICCION res
    ON res.NU_DNI = a.NU_DNI  -- ajustar clave según modelo real

-- Foto: esquema IMAGADM - IDTP_IMAGENES (mayores), IDTP_IMAGEN_MENOR (menores)
-- Ajustar: nombre de columna de imagen (IM_FOTO, IMAGEN, etc.) y clave de JOIN
-- (doc. Excel: cruce por TIPO y NRO FICHA IMAGEN o NU_FORMULARIO; aquí se usa NU_DNI como ejemplo)
LEFT JOIN IMAGADM.IDTP_IMAGENES img_mayor
    ON img_mayor.NU_DNI = a.NU_DNI
LEFT JOIN IMAGADM.IDTP_IMAGEN_MENOR img_menor
    ON img_menor.NU_DNI = a.NU_DNI

WHERE
    a.NU_DNI = :p_numero_dni  -- parámetro de entrada (ej. 12345678)
;

-- =============================================================================
-- VERSIÓN SIMPLIFICADA: solo GETM_ANI (sin JOINs a ubigeos, catálogos, foto)
-- Útil para probar o cuando las tablas/vistas auxiliares tengan otros nombres.
-- =============================================================================
/*
SELECT
    a.NU_DNI                    AS cui_numero_dni,           -- (01)
    a.PRENOM_INSCRITO           AS nombres,                 -- (02)
    a.AP_PRIMER                 AS apellido_paterno,         -- (03)
    a.AP_SEGUNDO                AS apellido_materno,         -- (04)
    a.AP_CASADA                 AS apellido_casada,         -- (05)
    a.FE_NACIMIENTO             AS fecha_nacimiento,         -- (06)
    NULL                        AS lugar_nacimiento,         -- (07) desde GEVW_UBIGEO
    NULL                        AS ubigeo_nacimiento,       -- (08) desde GEVW_UBIGEO
    a.DE_GENERO                 AS sexo,                    -- (09) o desde GETR_DOMINIOS
    a.DE_ESTADO_CIVIL           AS estado_civil,             -- (10) o desde GETR_ESTADO_CIVIL
    NULL                        AS foto,                     -- (11) desde IMAGADM
    NULL                        AS ubigeo_domicilio,         -- (12) desde GEVW_UBIGEO
    NULL                        AS lugar_domicilio,          -- (13) desde GEVW_UBIGEO
    a.DE_PREF_DIRECCION || ' ' || NVL(a.DE_DIRECCION,'')    AS domicilio,  -- (14)
    NULL                        AS grupo_factor_sanguineo,   -- (15) desde GETR_GRUPO_FACTOR_SANGUINEO
    NULL                        AS observaciones,            -- (16) desde GETM_OBSERVACION_DNI
    NULL                        AS restriccion,              -- (17) desde GETM_RESTRICCION
    a.FE_EMISION                AS fecha_emision_dnie,       -- 18
    CASE WHEN EXTRACT(YEAR FROM a.FE_CADUCIDAD) = 3000 THEN 'NO CADUCA' ELSE TO_CHAR(a.FE_CADUCIDAD) END AS fecha_caducidad_dnie,  -- 19
    a.CO_TIPO_DOC_PADRE         AS tipo_documento_padre,      -- (20)
    a.NU_DOC_PADRE              AS numero_documento_padre,   -- (21)
    a.CO_TIPO_DOC_MADRE         AS tipo_documento_madre,     -- (22)
    a.NU_DOC_MADRE              AS numero_documento_madre,   -- (23) si existe; si no, NU_DOC_PADRE según Excel
    NULL                        AS nacionalidad,             -- 25
    NULL                        AS correo_electronico,       -- 26
    NULL                        AS celular                    -- 27
FROM IDOTABMAESTRA.GETM_ANI a
WHERE a.NU_DNI = :p_numero_dni;
*/

-- =============================================================================
-- Resumen de campos por Etiqueta MOCKUP (credenciales-from-emma.xlsx)
-- =============================================================================
-- (01) CUI             -> GETM_ANI.NU_DNI
-- (02) Nombres         -> GETM_ANI.PRENOM_INSCRITO
-- (03) Ap. paterno     -> GETM_ANI.AP_PRIMER
-- (04) Ap. materno     -> GETM_ANI.AP_SEGUNDO
-- (05) Ap. casada      -> GETM_ANI.AP_CASADA
-- (06) Fecha nac.      -> GETM_ANI.FE_NACIMIENTO
-- (07) Lugar nac.      -> GEVW_UBIGEO.DE_UBIGEO_CAPTU (nacimiento)
-- (08) UBIGEO nac.     -> GEVW_UBIGEO.CO_UBIGEO (nacimiento)
-- (09) Sexo            -> GETR_DOMINIOS.DE_DOM (TIPO_SEXO) o GETM_ANI
-- (10) Estado civil    -> GETR_ESTADO_CIVIL.DE_ESTADO_CIVIL
-- (11) Foto            -> IMAGADM.IDTP_IMAGENES.IM_FOTO, IMAGADM.IDTP_IMAGEN_MENOR.IM_FOTO
-- (12) UBIGEO dom.     -> GEVW_UBIGEO.CO_UBIGEO (domicilio)
-- (13) Lugar dom.      -> GEVW_UBIGEO.DE_UBIGEO_CAPTU (domicilio)
-- (14) Domicilio       -> GETM_ANI (DE_PREF_DIRECCION, DE_DIRECCION, etc.)
-- (15) Grupo sanguíneo -> GETR_GRUPO_FACTOR_SANGUINEO.DE_GRUPO_FACTOR
-- (16) Observaciones   -> GETM_OBSERVACION_DNI + GETR_OBSERVACION.DE_OBS
-- (17) Restricción     -> GETM_RESTRICCION
-- 18   F. emisión DNIe -> GETM_ANI.FE_EMISION
-- 19   F. caducidad    -> GETM_ANI.FE_CADUCIDAD
-- (20)-(23) Padre/Madre -> GETM_ANI (CO_TIPO_DOC_*, NU_DOC_*)
-- 25   Nacionalidad    -> Pendiente en Excel
-- 26   Correo          -> Pendiente en Excel
-- 27   Celular         -> Pendiente (DE_CEL con DECODE)
-- =============================================================================
