#!/bin/bash
# Limpia todas las tablas del esquema IDORRCC y recrea las tablas según los CSV.
# Requiere: contenedor Docker 'oracle-free' en ejecución.
# Uso: ./sql/ejecutar_limpieza_y_recrear.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."

echo "=========================================="
echo "Limpieza y recreación de tablas Oracle"
echo "=========================================="

if ! docker ps | grep -q oracle-free; then
    echo "❌ Error: El contenedor 'oracle-free' no está ejecutándose."
    exit 1
fi

echo "1/2 Eliminando tablas y procedimientos en IDORRCC..."
docker exec -i oracle-free sqlplus -s system/oracle@FREEPDB1 < sql/00_drop_all_tables.sql

echo ""
echo "2/2 Creando tablas (GETM_ANI, GEVW_UBIGEOS, GETR_*, IDTP_*)..."
docker exec -i oracle-free sqlplus -s system/oracle@FREEPDB1 < sql/02_create_tables_from_csv.sql

echo ""
echo "✓ Limpieza y recreación completadas."
echo "  Tablas creadas: GETR_ESTADO_CIVIL, GETR_GRUPO_FACTOR_SANGUINEO, GETR_OBSERVACION,"
echo "  GETR_DOMINIOS, GEVW_UBIGEOS, GETM_RESTRICCION, GETM_ANI, GETM_OBSERVACION_DNI,"
echo "  IDTP_IMAGENES, IDTP_IMAGEN_MENOR."
