-- Creación de tablas según definiciones CSV (esquema IDORRCC)
-- Ejecutar después de 00_drop_all_tables.sql y 01_create_schema.sql
-- Uso: docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/02_create_tables_from_csv.sql

ALTER SESSION SET CURRENT_SCHEMA = IDORRCC;

-- ============================================
-- GETR_ESTADO_CIVIL (catálogo)
-- ============================================
CREATE TABLE IDORRCC.GETR_ESTADO_CIVIL (
    co_estado_civil     CHAR(2) NOT NULL,
    de_estado_civil     VARCHAR2(200),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETR_ESTADO_CIVIL PRIMARY KEY (co_estado_civil)
);

-- ============================================
-- GETR_GRUPO_FACTOR_SANGUINEO (catálogo)
-- ============================================
CREATE TABLE IDORRCC.GETR_GRUPO_FACTOR_SANGUINEO (
    co_grupo_factor     NUMBER NOT NULL,
    de_grupo_factor     VARCHAR2(100),
    es_grupo_factor     CHAR(1),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETR_GRUPO_FACTOR_SANGUINEO PRIMARY KEY (co_grupo_factor)
);

-- ============================================
-- GETR_OBSERVACION (catálogo)
-- ============================================
CREATE TABLE IDORRCC.GETR_OBSERVACION (
    co_obs              CHAR(10) NOT NULL,
    co_gru_obs          VARCHAR2(20),
    de_obs              VARCHAR2(500),
    es_observacion      CHAR(1),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    in_disc_inter       CHAR(1),
    in_imprime_observacion CHAR(1),
    ti_obs              CHAR(2),
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETR_OBSERVACION PRIMARY KEY (co_obs)
);

-- ============================================
-- GETR_DOMINIOS (catálogo)
-- ============================================
CREATE TABLE IDORRCC.GETR_DOMINIOS (
    co_dominio          VARCHAR2(50) NOT NULL,
    ce_dom              VARCHAR2(50),
    no_dom              VARCHAR2(200),
    de_dom              VARCHAR2(500),
    de_dom_detalle      VARCHAR2(500),
    es_dom              CHAR(1),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETR_DOMINIOS PRIMARY KEY (co_dominio)
);

-- ============================================
-- GEVW_UBIGEOS (vista/maestro ubigeos)
-- ============================================
CREATE TABLE IDORRCC.GEVW_UBIGEOS (
    co_ubigeo           VARCHAR2(20) NOT NULL,
    co_ubigeo_m         VARCHAR2(20),
    co_ubigeo_o         CHAR(10),
    co_centro_poblado   VARCHAR2(50),
    co_centro_poblado_o CHAR(10),
    co_continente       CHAR(5),
    co_deno             CHAR(10),
    co_departamento     CHAR(5),
    co_distrito         CHAR(5),
    co_pais             CHAR(5),
    co_postal           VARCHAR2(20),
    co_provincia        CHAR(5),
    co_region           VARCHAR2(100),
    de_centro_poblado   VARCHAR2(200),
    de_deno             VARCHAR2(200),
    de_region           VARCHAR2(200),
    de_resol_alta       VARCHAR2(200),
    de_resol_baja       VARCHAR2(200),
    de_ubigeo           VARCHAR2(200),
    de_ubigeo_captu     VARCHAR2(200),
    de_ubigeo_detalle   VARCHAR2(500),
    estado              VARCHAR2(20),
    es_ubigeo           CHAR(1),
    fe_alta             DATE,
    fe_baja             DATE,
    in_dep_capital      VARCHAR2(5),
    in_dis_capital      VARCHAR2(5),
    in_extr_pobr        CHAR(1),
    in_nacimiento       CHAR(1),
    in_pro_capital      VARCHAR2(5),
    in_reinscripcion    CHAR(1),
    in_revocatoria      CHAR(1),
    no_continente       VARCHAR2(100),
    no_departamento     VARCHAR2(100),
    no_distrito         VARCHAR2(100),
    no_pais             VARCHAR2(100),
    no_provincia        VARCHAR2(100),
    ub_inei             VARCHAR2(20),
    ub_sunat            VARCHAR2(20),
    CONSTRAINT PK_GEVW_UBIGEOS PRIMARY KEY (co_ubigeo)
);

-- ============================================
-- GETM_RESTRICCION (maestro restricciones)
-- ============================================
CREATE TABLE IDORRCC.GETM_RESTRICCION (
    co_restri           VARCHAR2(20) NOT NULL,
    co_grupo_restri     CHAR(5),
    de_restri           VARCHAR2(500),
    de_cel              VARCHAR2(500),
    es_restri           CHAR(1),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    in_cel              CHAR(1),
    in_certif_dig       CHAR(1),
    in_consulta_cel     CHAR(1),
    in_declarante       CHAR(1),
    in_entrega_dni_otro CHAR(1),
    in_entrega_dni_pariente CHAR(1),
    in_entrega_dni_segundo CHAR(1),
    in_entrega_dni_titular CHAR(1),
    in_reclamos         CHAR(1),
    in_reinscripcion    CHAR(1),
    in_restringe_cdef   CHAR(1),
    in_restringe_reg_ace CHAR(1),
    in_restringe_reg_nac_rrcc CHAR(1),
    in_verificacion_biometrica CHAR(1),
    ti_restri           CHAR(5),
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETM_RESTRICCION PRIMARY KEY (co_restri)
);

-- ============================================
-- GETM_ANI (maestro DNI / acta nacimiento inscripción)
-- ============================================
CREATE TABLE IDORRCC.GETM_ANI (
    nu_dni                  VARCHAR2(20) NOT NULL,
    ap_primer               VARCHAR2(100),
    ap_segundo              VARCHAR2(100),
    ap_casada               VARCHAR2(100),
    ap_conyuge_primer       VARCHAR2(100),
    ap_conyuge_segundo      VARCHAR2(100),
    ap_conyuge_casada       VARCHAR2(100),
    ap_decla_primer         VARCHAR2(100),
    ap_decla_segundo        VARCHAR2(100),
    ap_decla_casada         VARCHAR2(100),
    ap_madre_primer         VARCHAR2(100),
    ap_madre_segundo        VARCHAR2(100),
    ap_madre_casada         VARCHAR2(100),
    ap_padre_primer         VARCHAR2(100),
    ap_padre_segundo        VARCHAR2(100),
    ap_resp_primer          VARCHAR2(100),
    ap_resp_segundo         VARCHAR2(100),
    ap_resp_casada          VARCHAR2(100),
    prenom_inscrito         VARCHAR2(200),
    prenom_conyuge          VARCHAR2(200),
    prenom_decla            VARCHAR2(200),
    prenom_madre            VARCHAR2(200),
    prenom_padre            VARCHAR2(200),
    prenom_resp             VARCHAR2(200),
    co_estado_civil         CHAR(2),
    co_grupo_sanguineo      NUMBER,
    co_centro_poblado_domicilio CHAR(10),
    co_centro_poblado_naci  CHAR(10),
    co_centro_poblado_restri CHAR(10),
    co_continente_domicilio CHAR(5),
    co_continente_naci      CHAR(5),
    co_continene_restri     CHAR(5),
    co_decla                VARCHAR2(20),
    co_dedo_derecho         CHAR(5),
    co_dedo_izquierdo       CHAR(5),
    co_departamento_domicilio CHAR(5),
    co_departamento_naci    CHAR(5),
    co_departamento_restri  CHAR(5),
    co_discapacidad         CHAR(5),
    co_distrito_domicilio   CHAR(5),
    co_distrito_naci        CHAR(5),
    co_distrito_restri      CHAR(5),
    co_doc_adj              VARCHAR2(20),
    co_doc_emi              VARCHAR2(20),
    co_interdiccion         CHAR(5),
    co_nivel_educa          VARCHAR2(20),
    co_obs                  CHAR(10),
    co_pais_domicilio       CHAR(5),
    co_pais_naci            CHAR(5),
    co_pais_restri          CHAR(5),
    co_postal               VARCHAR2(20),
    co_provincia_domicilio  CHAR(5),
    co_provincia_naci       CHAR(5),
    co_provincia_restri     CHAR(5),
    co_restri               VARCHAR2(20),
    co_tipo_doc_conyuge     CHAR(5),
    co_tipo_doc_declarante  CHAR(5),
    co_tipo_doc_madre       CHAR(5),
    co_tipo_doc_padre       CHAR(5),
    co_tipo_doc_resp        CHAR(5),
    co_vinculo              VARCHAR2(20),
    co_votacion             CHAR(5),
    de_block_chalet         VARCHAR2(100),
    de_direccion            VARCHAR2(500),
    de_email                VARCHAR2(200),
    de_estatura             CHAR(20),
    de_etapa                VARCHAR2(100),
    de_genero               CHAR(5),
    de_interior             VARCHAR2(100),
    de_lote_direccion       VARCHAR2(100),
    de_manzana              VARCHAR2(100),
    de_pref_block           VARCHAR2(50),
    de_pref_direccion       VARCHAR2(50),
    de_pref_interior        VARCHAR2(50),
    de_pref_urb             VARCHAR2(50),
    de_urbanizacion         VARCHAR2(200),
    digito_verificacion     CHAR(1),
    fe_caducidad            DATE,
    fe_crea_audi            DATE,
    fe_emision              DATE,
    fe_inscripcion          DATE,
    fe_modi_audi            DATE,
    fe_nacimiento           DATE,
    fe_restri               DATE,
    gp_votacion             CHAR(5),
    in_busca_text           CHAR(1),
    in_dona_organo          CHAR(1),
    in_emision              CHAR(1),
    in_imprime_casada       CHAR(1),
    in_imprime_discapacidad CHAR(1),
    in_imprime_interdiccion CHAR(1),
    in_inter_disc           CHAR(1),
    in_registro_civil       CHAR(1),
    nu_acta_registral       NUMBER,
    nu_direccion            VARCHAR2(50),
    nu_dni_testigo1         VARCHAR2(20),
    nu_dni_testigo2         VARCHAR2(20),
    nu_doc_adj              VARCHAR2(50),
    nu_doc_ant              VARCHAR2(50),
    nu_doc_conyuge          VARCHAR2(20),
    nu_doc_declarante       VARCHAR2(20),
    nu_doc_madre            VARCHAR2(20),
    nu_doc_padre            VARCHAR2(20),
    nu_doc_resp             VARCHAR2(20),
    nu_ficha_reg            VARCHAR2(50),
    nu_mag                  VARCHAR2(50),
    nu_telefono             VARCHAR2(30),
    score_hue_der           NUMBER,
    score_hue_izq           NUMBER,
    ti_ficha_imag           CHAR(5),
    ti_ficha_reg            CHAR(5),
    ti_testigo01            VARCHAR2(100),
    ti_testigo02            VARCHAR2(100),
    us_crea_audi            VARCHAR2(100),
    us_modi_audi            VARCHAR2(100),
    CONSTRAINT PK_GETM_ANI PRIMARY KEY (nu_dni)
);

-- ============================================
-- GETM_OBSERVACION_DNI (relación DNI - observaciones)
-- ============================================
CREATE TABLE IDORRCC.GETM_OBSERVACION_DNI (
    nu_dni              VARCHAR2(20) NOT NULL,
    co_obs              CHAR(10) NOT NULL,
    es_observacion      CHAR(1),
    fe_crea_audi        DATE,
    fe_modi_audi        DATE,
    us_crea_audi        VARCHAR2(100),
    us_modi_audi        VARCHAR2(100),
    CONSTRAINT PK_GETM_OBSERVACION_DNI PRIMARY KEY (nu_dni, co_obs)
);

-- ============================================
-- IDTP_IMAGENES (imágenes DNI - ordimage sustituido por BLOB)
-- ============================================
CREATE TABLE IDORRCC.IDTP_IMAGENES (
    nu_formulario       CHAR(20) NOT NULL,
    ti_doc_reg_ficha    CHAR(10) NOT NULL,
    bi_template         BLOB,
    mi_firma            BLOB,
    im_foto             BLOB,
    mi_huella_derecha   BLOB,
    mi_huella_izquierda BLOB,
    CONSTRAINT PK_IDTP_IMAGENES PRIMARY KEY (nu_formulario, ti_doc_reg_ficha)
);

-- ============================================
-- IDTP_IMAGEN_MENOR (imágenes DNI menor)
-- ============================================
CREATE TABLE IDORRCC.IDTP_IMAGEN_MENOR (
    nu_formulario           CHAR(20) NOT NULL,
    ti_doc_reg_ficha        CHAR(10) NOT NULL,
    bi_template             BLOB,
    mi_firma_declarante     BLOB,
    im_foto_menor           BLOB,
    mi_huella_der_declarante BLOB,
    mi_huella_izq_declarante BLOB,
    CONSTRAINT PK_IDTP_IMAGEN_MENOR PRIMARY KEY (nu_formulario, ti_doc_reg_ficha)
);

-- Índices útiles
CREATE INDEX IDX_GETM_ANI_ESTADO_CIVIL ON IDORRCC.GETM_ANI(co_estado_civil);
CREATE INDEX IDX_GETM_ANI_FE_NACIMIENTO ON IDORRCC.GETM_ANI(fe_nacimiento);
CREATE INDEX IDX_GETM_OBS_DNI_NU_DNI ON IDORRCC.GETM_OBSERVACION_DNI(nu_dni);
CREATE INDEX IDX_GETM_OBS_DNI_CO_OBS ON IDORRCC.GETM_OBSERVACION_DNI(co_obs);
CREATE INDEX IDX_GEVW_UBIGEOS_DEPTO ON IDORRCC.GEVW_UBIGEOS(co_departamento);

COMMIT;
PROMPT Tablas creadas correctamente.
