-- Migración: actualizar nombres de columnas para coincidir con draft_query.sql
-- Ejecutar en una base que ya tiene las tablas creadas (ej. IDORRCC en Docker).
-- Para esquema IDOTABMAESTRA/IMAGADM cambiar IDORRCC por el esquema correspondiente.

WHENEVER SQLERROR CONTINUE;

-- GETM_ANI: renombrar nu_direcccion -> nu_direccion (si existe la columna antigua)
ALTER TABLE IDORRCC.GETM_ANI RENAME COLUMN nu_direcccion TO nu_direccion;

-- GETR_DOMINIOS: agregar de_dom (descripción del dominio)
ALTER TABLE IDORRCC.GETR_DOMINIOS ADD de_dom VARCHAR2(500);

-- GEVW_UBIGEOS: renombrar co_continene -> co_continente
ALTER TABLE IDORRCC.GEVW_UBIGEOS RENAME COLUMN co_continene TO co_continente;

-- IDTP_IMAGENES: renombrar mi_foto -> im_foto
ALTER TABLE IDORRCC.IDTP_IMAGENES RENAME COLUMN mi_foto TO im_foto;

-- IDTP_IMAGEN_MENOR: renombrar mi_foto_menor -> im_foto_menor
ALTER TABLE IDORRCC.IDTP_IMAGEN_MENOR RENAME COLUMN mi_foto_menor TO im_foto_menor;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
COMMIT;
PROMPT Columnas actualizadas.
EXIT;
