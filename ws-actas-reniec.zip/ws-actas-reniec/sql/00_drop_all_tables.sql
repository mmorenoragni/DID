-- Limpieza de todas las tablas y procedimientos del esquema IDORRCC
-- Ejecutar como system (o usuario con privilegios) conectado a FREEPDB1
-- Uso: docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_drop_all_tables.sql

WHENEVER SQLERROR CONTINUE;

-- Eliminar procedimientos almacenados que referencian tablas
BEGIN
  FOR r IN (SELECT object_name FROM all_objects WHERE owner = 'IDORRCC' AND object_type = 'PROCEDURE') LOOP
    EXECUTE IMMEDIATE 'DROP PROCEDURE IDORRCC.' || r.object_name;
  END LOOP;
END;
/

-- Eliminar todas las tablas del esquema IDORRCC (CASCADE CONSTRAINTS para no fallar por FKs)
BEGIN
  FOR t IN (SELECT table_name FROM all_tables WHERE owner = 'IDORRCC') LOOP
    EXECUTE IMMEDIATE 'DROP TABLE IDORRCC.' || t.table_name || ' CASCADE CONSTRAINTS PURGE';
  END LOOP;
END;
/

-- Eliminar secuencias si existieran
BEGIN
  FOR s IN (SELECT sequence_name FROM all_sequences WHERE sequence_owner = 'IDORRCC') LOOP
    EXECUTE IMMEDIATE 'DROP SEQUENCE IDORRCC.' || s.sequence_name;
  END LOOP;
END;
/

WHENEVER SQLERROR EXIT SQL.SQLCODE;

PROMPT Limpieza completada. Tablas y procedimientos del esquema IDORRCC eliminados.
