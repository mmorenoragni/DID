# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build

```bash
mvn clean package
```

Produces `target/ws-actas-dnid.war`. Targets Java 1.8 with UTF-8 encoding. There are no automated tests in this project — testing is done manually via curl (examples in `despliegue-actas.md`).

## Tech Stack

- **Java 8 + Java EE 7** (Servlets, JNDI), deployed on **Oracle WebLogic 12c**
- **Oracle Database** (two schemas: `IDORRCC` for civil records, `DESADNI` for identity/DNI validation)
- **Gson** for JSON serialization; **ojdbc8** for Oracle connectivity
- Context root: `/ws-actas-dnid`

## Architecture

The application exposes two servlets:

- `POST /ObtenerDatosDNId` — main query endpoint ([ObtenerDatosDNIdServlet.java](src/main/java/com/dnid/servlet/ObtenerDatosDNIdServlet.java))
- `GET /health` — JNDI DataSource health check ([HealthCheckServlet.java](src/main/java/com/dnid/servlet/HealthCheckServlet.java))

### Strategy Pattern for Profiles

`ObtenerDatosDNIdServlet` dispatches to a `DnidProfileStrategy` implementation based on the `profile` request parameter:

| Profile | Strategy class | Stored Procedure | JNDI used |
|---|---|---|---|
| `ACTA_NACIMIENTO` | `ActaNacimientoProfileStrategy` | `SP_OBTENER_ACTA_NACIMIENTO(nu_acta, cursor)` | `jdbc/desarc` |
| `ACTA_MATRIMONIO` | `ActaMatrimonioProfileStrategy` | `SP_ACTA_MATRIMONIO_BY_DOC(dni, cursor)` | `jdbc/desarc` |
| `ACTA_NACIMIENTO_FILIACION` | `ActaNacimientoConFiliacionProfileStrategy` | `SP_GET_DATOS_COMPLETO_DNI()` + nacimiento SP | `jdbc/desadni` + `jdbc/desarc` |

To add a new profile, implement `DnidProfileStrategy`, register it in the servlet's profile map.

### Database Connections

[DatabaseConnection.java](src/main/java/com/dnid/util/DatabaseConnection.java) wraps JNDI lookups for both data sources. JNDI names are declared in [web.xml](src/main/webapp/WEB-INF/web.xml) and mapped to WebLogic global JNDI in [weblogic.xml](src/main/webapp/WEB-INF/weblogic.xml). Connections are obtained only via JNDI.

### Image Handling

[ImageCompressionUtil.java](src/main/java/com/dnid/util/ImageCompressionUtil.java) converts Oracle BLOB columns to Base64 strings. Images over 5000 bytes are resized to max 64px width at 0.75 JPEG quality before encoding.

### Business Exception Codes (ACTA_NACIMIENTO_FILIACION)

`FiliacionNegocioException` carries one of: `ERROR_FORMATO` (→ 400), `ACCESO_DENEGADO` (→ 403), `DNI_CADUCO` (→ 400), `SIN_FILIACION` (→ 403). `DatosNoEncontradosException` maps to 404.

## WebLogic Configuration

Two JNDI DataSources must be configured before deployment:

- **`jdbc/desarc`** — IDORRCC schema (civil registry records)
- **`jdbc/desadni`** — DNI schema (identity validation)

See [despliegue-actas.md](despliegue-actas.md) for full WebLogic console walkthrough and [docs/](docs/) for JNDI screenshots.

## Database Setup

SQL scripts in [sql/](sql/) create the Oracle schema, tables, stored procedures, and sample data. Run them against the `IDORRCC` schema (or use `sql/00_all_in_one.sql` for everything at once):

```bash
docker exec -i oracle-free sqlplus system/oracle@FREEPDB1 < sql/00_all_in_one.sql
```

## API Quick Reference

All responses are `application/json; charset=UTF-8`. Errors always return `{"error": "..."}` with an appropriate HTTP status (400/403/404/405/500/503).

```bash
# Health check
curl -s "http://localhost:7001/ws-actas-dnid/health"

# Birth certificate by acta number
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -H "Content-Type: application/json" \
  -d '{"profile":"ACTA_NACIMIENTO","dni":"1001"}'

# Marriage certificate by DNI
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -H "Content-Type: application/json" \
  -d '{"profile":"ACTA_MATRIMONIO","dni":"12345678"}'

# Birth certificate with filiation validation
curl -s -X POST "http://localhost:7001/ws-actas-dnid/ObtenerDatosDNId" \
  -H "Content-Type: application/json" \
  -d '{"profile":"ACTA_NACIMIENTO_FILIACION","dni":"12345678","dni_filiacion":"87654321"}'
```
